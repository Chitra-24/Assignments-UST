package com.JPACRUD.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.JPACRUD.model.Department;
import com.JPACRUD.model.Student;
import com.JPACRUD.repository.DepartmentRepository;
import com.JPACRUD.repository.StudentRepository;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private DepartmentRepository departmentRepository;
    
    /*public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }
    */
    public Student saveStudent(Student student) {
        Department department = student.getDepartment();
        if (department != null) {
            Optional<Department> existingDepartment = departmentRepository.findById(department.getId());
            if (!existingDepartment.isPresent()) {
                department = departmentRepository.save(department);
            } else {
                department = existingDepartment.get();
            }
            student.setDepartment(department);
        }
        return studentRepository.save(student);
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(Long id) {
        return studentRepository.findById(id).orElse(null);
    }

    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }

    // Pagination and Sorting
    public Page<Student> getStudentsWithPaginationAndSorting(int page, int size, String sortBy) {
        return studentRepository.findAll(PageRequest.of(page, size, Sort.by(sortBy)));
    }

    // Custom query
    @Cacheable("studentsByName")
    public List<Student> getStudentsByName(String name) {
        return studentRepository.findByName(name);
    }
}
