package com.ecom.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ecom.model.Category;
import com.ecom.repository.CategoryRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class CategoryServiceTest {

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private CategoryService categoryService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void getAllCategories() {
        List<Category> categoryList = new ArrayList<>();
        categoryList.add(new Category("Category 1"));
        categoryList.add(new Category("Category 2"));

        when(categoryRepository.findAll()).thenReturn(categoryList);

        List<Category> result = categoryService.getAllCategories();

        assertEquals(2, result.size());
    }

    @Test
    void getCategoryById() {
        Category category = new Category("Category 1");
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category));

        Optional<Category> result = categoryService.getCategoryById(1L);

        assertEquals(category, result.orElse(null));
    }

    @Test
    void createCategory() {
        Category category = new Category("Category 1");
        when(categoryRepository.save(category)).thenReturn(category);

        Category result = categoryService.createCategory(category);

        assertEquals(category, result);
    }

    @Test
    void updateCategory() {
        Category existingCategory = new Category("Category 1");
        existingCategory.setId(1L);
        Category updatedCategory = new Category("Updated Category 1");
        when(categoryRepository.existsById(1L)).thenReturn(true);
        when(categoryRepository.save(updatedCategory)).thenReturn(updatedCategory);

        Category result = categoryService.updateCategory(1L, updatedCategory);

        assertEquals(updatedCategory, result);
    }

    @Test
    void deleteCategory() {
        doNothing().when(categoryRepository).deleteById(1L);

        categoryService.deleteCategory(1L);

        verify(categoryRepository, times(1)).deleteById(1L);
    }
}

