package com.ecom.service;

import com.ecom.model.Category;
import com.ecom.model.Order;
import com.ecom.model.Product;
import com.ecom.repository.CategoryRepository;
import com.ecom.repository.OrderRepository;
import com.ecom.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private ProductService productService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void getAllProducts() {
        List<Product> productList = new ArrayList<>();
        productList.add(new Product("Product 1", 10.0, new Category("Category 1")));
        productList.add(new Product("Product 2", 20.0, new Category("Category 2")));

        when(productRepository.findAll()).thenReturn(productList);

        List<Product> result = productService.getAllProducts();

        assertEquals(2, result.size());
    }

    @Test
    void getProductById() {
        Product product = new Product("Product 1", 10.0, new Category("Category 1"));
        when(productRepository.findById(1L)).thenReturn(Optional.of(product));

        Optional<Product> result = productService.getProductById(1L);

        assertEquals(product, result.orElse(null));
    }

    @Test
    void getProductsByCategory() {
        Category category = new Category("Category 1");
        category.setId(1L);
        List<Product> productList = new ArrayList<>();
        productList.add(new Product("Product 1", 10.0, category));
        productList.add(new Product("Product 2", 20.0, category));

        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category));
        when(productRepository.findByCategory(category)).thenReturn(productList);

        List<Product> result = productService.getProductsByCategory(1L);

        assertEquals(2, result.size());
    }


    @Test
    void createProduct() {
        Product product = new Product("Product 1", 10.0, new Category("Category 1"));
        when(productRepository.save(product)).thenReturn(product);

        Product result = productService.createProduct(product);

        assertEquals(product, result);
    }

    @Test
    void updateProduct() {
        Product existingProduct = new Product("Product 1", 10.0, new Category("Category 1"));
        existingProduct.setId(1L);
        Product updatedProduct = new Product("Updated Product 1", 20.0, new Category("Category 2"));
        when(productRepository.existsById(1L)).thenReturn(true);
        when(productRepository.save(updatedProduct)).thenReturn(updatedProduct);

        Product result = productService.updateProduct(1L, updatedProduct);

        assertEquals(updatedProduct, result);
    }

    @Test
    void deleteProduct() {
        doNothing().when(productRepository).deleteById(1L);

        productService.deleteProduct(1L);

        verify(productRepository, times(1)).deleteById(1L);
    }
}
