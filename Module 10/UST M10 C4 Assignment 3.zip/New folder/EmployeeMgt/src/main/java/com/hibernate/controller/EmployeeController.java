package com.hibernate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.hibernate.entity.Employee;
import com.hibernate.service.EmployeeService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

 @Autowired
 private EmployeeService employeeService;

 @GetMapping
 public List<Employee> getAllEmployees() {
     return employeeService.getAllEmployees();
 }

 @GetMapping("/{id}")
 public Optional<Employee> getEmployeeById(@PathVariable Long id) {
     return employeeService.getEmployeeById(id);
 }

 @PostMapping
 public Employee createEmployee(@RequestBody Employee employee) {
     return employeeService.saveEmployee(employee);
 }

 @PutMapping("/{id}")
 public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails) {
     return employeeService.updateEmployee(id, employeeDetails);
 }

 @DeleteMapping("/{id}")
 public void deleteEmployee(@PathVariable Long id) {
     employeeService.deleteEmployee(id);
 }

 @GetMapping("/more-than-five-years")
 public List<String> findEmployeesWithMoreThanFiveYears() {
     return employeeService.findEmployeesWithMoreThanFiveYears();
 }

 @GetMapping("/salary-greater-than/{salary}")
 public List<Employee> findEmployeesBySalaryGreaterThan(@PathVariable Double salary) {
     return employeeService.findEmployeesBySalaryGreaterThan(salary);
 }
}
