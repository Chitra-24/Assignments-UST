package com.hibernate.repository;

import com.hibernate.entity.Employee;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	
    @Query("SELECT e.name FROM Employee e WHERE e.employmentStartDate <= :date")
    List<String> findEmployeesWithMoreThanFiveYears(@Param("date") LocalDate date);

    List<Employee> findBySalaryGreaterThan(Double salary);
}


