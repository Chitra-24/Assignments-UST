package com.hibernate.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.hibernate.entity.Department;
import com.hibernate.repository.DepartmentRepository;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

class DepartmentServiceTest {

 @InjectMocks
 private DepartmentService departmentService;

 @Mock
 private DepartmentRepository departmentRepository;

 private Department department;

 @BeforeEach
 void setUp() {
     MockitoAnnotations.openMocks(this);
     department = new Department("Engineering");
 }

 @Test
 void testGetAllDepartments() {
     when(departmentRepository.findAll()).thenReturn(Arrays.asList(department));
     List<Department> departments = departmentService.getAllDepartments();
     assertNotNull(departments);
     assertEquals(1, departments.size());
     verify(departmentRepository, times(1)).findAll();
 }

 @Test
 void testGetDepartmentById() {
     when(departmentRepository.findById(anyLong())).thenReturn(Optional.of(department));
     Optional<Department> foundDepartment = departmentService.getDepartmentById(1L);
     assertTrue(foundDepartment.isPresent());
     assertEquals("Engineering", foundDepartment.get().getName());
     verify(departmentRepository, times(1)).findById(anyLong());
 }

 @Test
 void testSaveDepartment() {
     when(departmentRepository.save(any(Department.class))).thenReturn(department);
     Department savedDepartment = departmentService.saveDepartment(department);
     assertNotNull(savedDepartment);
     assertEquals("Engineering", savedDepartment.getName());
     verify(departmentRepository, times(1)).save(any(Department.class));
 }

 @Test
 void testUpdateDepartment() {
     when(departmentRepository.findById(anyLong())).thenReturn(Optional.of(department));
     when(departmentRepository.save(any(Department.class))).thenReturn(department);

     department.setName("Human Resources");
     Department updatedDepartment = departmentService.updateDepartment(1L, department);
     assertNotNull(updatedDepartment);
     assertEquals("Human Resources", updatedDepartment.getName());
     verify(departmentRepository, times(1)).findById(anyLong());
     verify(departmentRepository, times(1)).save(any(Department.class));
 }

 @Test
 void testDeleteDepartment() {
     doNothing().when(departmentRepository).deleteById(anyLong());
     departmentService.deleteDepartment(1L);
     verify(departmentRepository, times(1)).deleteById(anyLong());
 }
}

