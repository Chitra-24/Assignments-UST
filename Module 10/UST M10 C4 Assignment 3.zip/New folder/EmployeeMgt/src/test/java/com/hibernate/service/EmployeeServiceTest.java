package com.hibernate.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.hibernate.entity.Department;
import com.hibernate.entity.Employee;
import com.hibernate.repository.EmployeeRepository;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

class EmployeeServiceTest {

 @InjectMocks
 private EmployeeService employeeService;

 @Mock
 private EmployeeRepository employeeRepository;

 private Employee employee;
 private Department department;

 @BeforeEach
 void setUp() {
     MockitoAnnotations.openMocks(this);
     department = new Department("Engineering");
     employee = new Employee("John Doe", "Developer", 60000.0, LocalDate.now().minusYears(6), department);
 }

 @Test
 void testGetAllEmployees() {
     when(employeeRepository.findAll()).thenReturn(Arrays.asList(employee));
     List<Employee> employees = employeeService.getAllEmployees();
     assertNotNull(employees);
     assertEquals(1, employees.size());
     verify(employeeRepository, times(1)).findAll();
 }

 @Test
 void testGetEmployeeById() {
     when(employeeRepository.findById(anyLong())).thenReturn(Optional.of(employee));
     Optional<Employee> foundEmployee = employeeService.getEmployeeById(1L);
     assertTrue(foundEmployee.isPresent());
     assertEquals("John Doe", foundEmployee.get().getName());
     verify(employeeRepository, times(1)).findById(anyLong());
 }

 @Test
 void testSaveEmployee() {
     when(employeeRepository.save(any(Employee.class))).thenReturn(employee);
     Employee savedEmployee = employeeService.saveEmployee(employee);
     assertNotNull(savedEmployee);
     assertEquals("John Doe", savedEmployee.getName());
     verify(employeeRepository, times(1)).save(any(Employee.class));
 }

 @Test
 void testUpdateEmployee() {
     when(employeeRepository.findById(anyLong())).thenReturn(Optional.of(employee));
     when(employeeRepository.save(any(Employee.class))).thenReturn(employee);

     employee.setName("Jane Doe");
     Employee updatedEmployee = employeeService.updateEmployee(1L, employee);
     assertNotNull(updatedEmployee);
     assertEquals("Jane Doe", updatedEmployee.getName());
     verify(employeeRepository, times(1)).findById(anyLong());
     verify(employeeRepository, times(1)).save(any(Employee.class));
 }

 @Test
 void testDeleteEmployee() {
     doNothing().when(employeeRepository).deleteById(anyLong());
     employeeService.deleteEmployee(1L);
     verify(employeeRepository, times(1)).deleteById(anyLong());
 }

 @Test
 void testFindEmployeesWithMoreThanFiveYears() {
     when(employeeRepository.findEmployeesWithMoreThanFiveYears(any(LocalDate.class)))
         .thenReturn(Arrays.asList("John Doe"));

     List<String> employees = employeeService.findEmployeesWithMoreThanFiveYears();
     assertNotNull(employees);
     assertEquals(1, employees.size());
     assertEquals("John Doe", employees.get(0));
     verify(employeeRepository, times(1)).findEmployeesWithMoreThanFiveYears(any(LocalDate.class));
 }

 @Test
 void testFindEmployeesBySalaryGreaterThan() {
     when(employeeRepository.findBySalaryGreaterThan(any(Double.class)))
         .thenReturn(Arrays.asList(employee));

     List<Employee> employees = employeeService.findEmployeesBySalaryGreaterThan(50000.0);
     assertNotNull(employees);
     assertEquals(1, employees.size());
     assertEquals("John Doe", employees.get(0).getName());
     verify(employeeRepository, times(1)).findBySalaryGreaterThan(any(Double.class));
 }
}

