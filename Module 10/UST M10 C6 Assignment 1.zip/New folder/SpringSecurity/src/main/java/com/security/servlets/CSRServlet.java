package com.security.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/csrf")
public class CSRServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<html><body>");
        response.getWriter().println("<form action='/SpringSecurity/csrf' method='POST'>");
        response.getWriter().println("Transfer Amount: <input type='text' name='amount' />");
        response.getWriter().println("<input type='submit' value='Transfer' />");
        response.getWriter().println("</form>");
        response.getWriter().println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String amount = request.getParameter("amount");
        if (amount != null && !amount.isEmpty()) {
            response.getWriter().println("Transferred amount: " + amount);
        } else {
            response.getWriter().println("No amount provided");
        }
    }
}
