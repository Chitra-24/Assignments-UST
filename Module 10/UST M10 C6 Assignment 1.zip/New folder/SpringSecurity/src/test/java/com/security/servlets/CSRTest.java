package com.security.servlets;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class CSRTest {
    @Test
    public void testCSRF() throws Exception {
        String urlString = "http://localhost:8080/SpringSecurity/csrf";
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        
        String params = "amount=1000";
        OutputStream os = connection.getOutputStream();
        os.write(params.getBytes());
        os.flush();
        os.close();

        int responseCode = connection.getResponseCode();
        assertEquals(200, responseCode);

      
        try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
         
            assertTrue(response.toString().contains("Transferred amount: 1000"));
        }
    }
}
