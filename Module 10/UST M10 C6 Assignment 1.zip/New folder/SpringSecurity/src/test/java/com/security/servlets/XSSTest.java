package com.security.servlets;

import static org.junit.Assert.*;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import org.junit.Test;

public class XSSTest {
    @Test
    public void testXSS() throws IOException {
        String input = "<script>alert('xss')</script>";
        String urlString = "http://localhost:8080/SpringSecurity/xss?input=" + input;
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        int responseCode = connection.getResponseCode();
        assertEquals(200, responseCode);
    }
}
