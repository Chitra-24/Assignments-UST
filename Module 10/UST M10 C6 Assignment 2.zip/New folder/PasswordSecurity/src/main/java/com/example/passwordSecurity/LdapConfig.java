package com.example.passwordSecurity;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class LdapConfig {

    @Bean
    public DefaultSpringSecurityContextSource contextSource() {
        return new DefaultSpringSecurityContextSource(
            Collections.singletonList("ldap://localhost:8389/"), "dc=springframework,dc=org");
    }

    @SuppressWarnings("deprecation")
	@Bean
    public PasswordEncoder ldapPasswordEncoder() {
        Map<String, PasswordEncoder> encoders = new HashMap<>();
        encoders.put("LDAP", new org.springframework.security.crypto.password.LdapShaPasswordEncoder());
        return new DelegatingPasswordEncoder("LDAP", encoders);
    }
}
