package com.example.passwordSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class passwordSecurityApp {

	public static void main(String[] args) {
		SpringApplication.run(passwordSecurityApp.class, args);
	}

}
