package com.form.WebPage;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

    @GetMapping("/home/login")
    public String login1() {
        return "login1"; 
    }

    @GetMapping("/home/logout")
    public String logout() {
        return "redirect:/login?logout"; 
    }
}
