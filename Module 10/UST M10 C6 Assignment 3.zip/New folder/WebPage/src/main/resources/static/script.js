
const users = [
    { username: "user1", password: "admin", role: "admin" },
    { username: "user2", password: "pass2", role: "user" }
];

document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        showMessage("success", "Login successful.");
        showContent(user.role);
        document.getElementById("logout-btn").style.display = "block";
        document.getElementById("login-form").reset();
    } else {
        showMessage("error", "Invalid username or password.");
    }
});

document.getElementById("logout-btn").addEventListener("click", function() {
    document.getElementById("content").style.display = "none";
    document.getElementById("logout-btn").style.display = "none";
    showMessage("info", "Logged out successfully.");
});

function showMessage(type, message) {
    document.getElementById("message").innerHTML = `<div class="${type}">${message}</div>`;
}

function showContent(role) {
    if (role === "admin") {
        document.getElementById("content").innerHTML = "<h3>Welcome Admin</h3>";
    } else {
        document.getElementById("content").innerHTML = "<h3>Welcome User</h3>";
    }
    document.getElementById("content").style.display = "block";
}
