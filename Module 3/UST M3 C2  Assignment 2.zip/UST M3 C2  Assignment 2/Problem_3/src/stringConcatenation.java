import java.lang.String;
public class stringConcatenation {

	public static void main(String[] args) {
		String str1="Chitra";
		String str2=" Shree";
		System.out.println("after concatenation: ");
		System.out.println(str1+str2);
		System.out.println("Using Method "+ str1.concat(str2));
	}

}
