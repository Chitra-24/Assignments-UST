import java.util.ArrayList;
public class arrayListExample {

	public static void main(String[] args) {
		ArrayList<String> myArrayList = new ArrayList<String>();
        myArrayList.add("apple");
        myArrayList.add("banana");
        myArrayList.add("orange");
        myArrayList.add("pear");
        System.out.println("My ArrayList: " + myArrayList);

	}

}
