
public class Data_types {

	public static void main(String[] args) {
		Double num1=100d;
		char initial='V';
		float num2=60f;
		boolean choice=true;
		int num3=16;
		System.out.println("The double value is: "+ num1);
		System.out.println("The character value is: "+ initial);
		System.out.println("The Float value is: "+ num2);
		System.out.println("The Boolean value is: "+ choice);
		System.out.println("The integer value is: "+ num3);
	}

}
