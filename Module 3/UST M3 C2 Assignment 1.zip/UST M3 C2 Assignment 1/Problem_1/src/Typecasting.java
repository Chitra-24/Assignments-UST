
public class Typecasting {

	public static void main(String[] args) {
		int value1=20;
		int value2=30;
		float result;
		result=value1*value2;
		System.out.println("Result after type cast is "+ result);
	}

}
