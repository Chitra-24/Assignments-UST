import java.util.ArrayList;
import java.util.*;

class Department{
	String deptCode;
	String deptName;
	String deptLoc;
	int deptYear;
	
	Department(String deptCode,String deptName,String deptLoc,int deptYear){
		this.deptCode=deptCode;
		this.deptName=deptName;
		this.deptLoc=deptLoc;
		this.deptYear=deptYear;
	}
	
	public void deptDisplay() {
		System.out.println("Dept code: "+deptCode + "\nDept Name: " + deptName + "\nDept Location: "
				+ deptLoc + "\nDept Year: " + deptYear);
	}
}

class Teaching_Staff extends Department{
	String Tid;
	String Tname;
	String Tqualification;
	String Tjoining;
	
	Teaching_Staff(String deptCode,String deptName,String deptLoc,int deptYear,String Tid,String Tname,String Tqualification,String Tjoining){
		super(deptCode,deptName,deptLoc,deptYear);
		this.Tid=Tid;
		this.Tname=Tname;
		this.Tqualification=Tqualification;
		this.Tjoining=Tjoining;
	}
	
	public void staffDisplay() {
		System.out.println("Teacher ID: "+Tid + "\nTeacher Name: " + Tname + "\nqualification: "
			+ Tqualification + "\nJoining: " + Tjoining + "\nDept Code: " + super.deptCode);
	}
}


class Student extends Teaching_Staff{
	String Sid;
	String Sname;
	String phone;
	String email;
	//String[][] subject=new String[4][2];
	
	Student(String deptCode,String deptName,String deptLoc,int deptYear,String Tid,String Tname,String Tqualification,String Tjoining,String Sid,String Sname,String phone,String email){
		super(deptCode,deptName,deptLoc,deptYear,Tid,Tname,Tqualification,Tjoining);
		this.Sid=Sid;
		this.Sname=Sname;
		this.phone=phone;
		this.email=email;
		
	}
	
	public void studentDisplay() {
		System.out.println("Student ID: "+Sid + "\nName: " + Sname + "\nPhone: "
			+ phone + "\nEmail: " + email + "\nDept Code: " + super.deptCode + "\nTeacherCode: " + super.Tid);
	}
}

class StudentMarks{
	String Sid;
	int sem;
	int sub1;
	int sub2;
	int sub3;
	int sub4;
	
	StudentMarks(String Sid,int sem,int sub1,int sub2,int sub3,int sub4){
		this.Sid=Sid;
		this.sem=sem;
		this.sub1=sub1;
		this.sub2=sub2;
		this.sub3=sub3;
		this.sub4=sub4;
	}
	public float TotalMarks() {
		float total=sub1+sub2+sub3+sub4;
		return total;
	}
	public float Average() {
		float avg=TotalMarks()/4;
		return avg;
	}
}
public class college_ {

	public static void main(String[] args) {
		Department[] D=new Department[5];
		Teaching_Staff[] T=new Teaching_Staff[7];
		Student[] S=new Student[5];
		ArrayList<StudentMarks> SM=new ArrayList();
		
		//Department Details
		D[0]=new Department("C01","CSE","Floor 5",1998);
		D[1]=new Department("E01","EEE","Floor 2",1999);
		D[2]=new Department("EC01","ECE","Floor 1",1997);
		D[3]=new Department("CV01","CVL","Floor 4",1995);
		D[4]=new Department("ME1","ME","Floor 3",2000);
		
		//Teaching staff Details
		T[0]=new Teaching_Staff("C01","CSE","Floor 5",1998,"T201","Jay","PhD","03/07/2001");
		T[1]=new Teaching_Staff("E01","EEE","Floor 2",1999,"T202","Paul","M.Tech","12/05/2005");
		T[2]=new Teaching_Staff("EC01","ECE","Floor 1",1997,"T203","Smith","PhD","23/07/2003");
		T[3]=new Teaching_Staff("CV01","CVL","Floor 4",1995,"T204","Suma","B.Tech","03/08/2002");
		T[4]=new Teaching_Staff("C01","CSE","Floor 5",1998,"T205","John","M.Tech","15/05/2001");
		T[5]=new Teaching_Staff("E01","EEE","Floor 2",1999,"T206","Mary","PhD","15/05/2006");
		T[6]=new Teaching_Staff("CV01","CVL","Floor 4",1995,"T206","Harry","M.Tech","21/05/2004");
		
		//Student Details
		S[0]=new Student("C01","CSE","Floor 5",1998,"T201","Jay","PhD","03/07/2001","RR01","Suhana","0099887766","suhana@gmail.com");
		S[1]=new Student("C01","CSE","Floor 5",1998,"T204","Suma","B.Tech","03/08/2002","RR02","Ram","0096787456","ram@gmail.com");
		S[2]=new Student("C01","CSE","Floor 5",1998,"T202","Paul","M.Tech","12/05/2005","RR03","Radha","2536987423","radha@gmail.com");
		S[3]=new Student("C01","CSE","Floor 5",1998,"T201","Jay","PhD","03/07/2001","RR04","Sunil","8956741236","sunil@gmail.com");
		S[4]=new Student("C01","CSE","Floor 5",1998,"T201","Jay","PhD","03/07/2001","RR05","Anil","1458769325","anil@gmail.com");
		
		//student marks
		SM.add(new StudentMarks("RR01",4,78,81,85,86));
		SM.add(new StudentMarks("RR02",4,80,85,82,80));
		SM.add(new StudentMarks("RR03",4,90,87,86,88));
		SM.add(new StudentMarks("RR04",4,90,95,91,90));
		SM.add(new StudentMarks("RR05",4,90,92,91,92));
		
		
		/*System.out.println("Display Department Details");
		for(int i=0;i<D.length;i++) {
		  System.out.println("Dept "+ i );
			D[i].deptDisplay();
			System.out.println();
		}
		System.out.println("Display Staff Details");
		for(int i=0;i<T.length;i++) {
		  System.out.println("Teacher "+ i );
			T[i].staffDisplay();
			System.out.println();
		}
		System.out.println("Display Student Details");
		for(int i=0;i<S.length;i++) {
			System.out.println("Student "+ i );
			S[i].studentDisplay();
			System.out.println();
		}*/
		
		//Student marks display
		System.out.println("Total and averge marks of students in a semester");
		for(StudentMarks marks:SM) {
			System.out.println("Student "+marks.Sid);
			System.out.println("Total marks is: "+marks.TotalMarks());
			System.out.println("Average marks is: "+marks.Average());
			System.out.println();
		}
	}
}
