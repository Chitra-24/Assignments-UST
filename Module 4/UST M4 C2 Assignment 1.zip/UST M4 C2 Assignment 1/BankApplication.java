package assignmentSerialize;

import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Bank implements Serializable{
	private String name;
	private String accNo;
	private String custId;
	private String phone;
	
	public Bank(String name,String accNo,String custId,String phone) {
		this.name=name;
		this.accNo=accNo;
		this.custId=custId;
		this.phone=phone;
	}
	
	public void setAcc(String accNo) {
		this.accNo=accNo;
	}
	public void setName(String name) {
		this.name=name;
	}
	public void setId(String custId) {
		this.custId=custId;
	}
	public void setPhone(String phone) {
		this.phone=phone;
	}
	
	public String getName() {
		return name;
	}
	public String getAcc() {
		return accNo;
	}
	public String getId() {
		return custId;
	}
	public String getPhone() {
		return phone;
	}
	
	public void display() {
	System.out.println("Customer Name: "+name+"\nAccountNo: "+accNo+
			"\nCustomer Id: "+custId+"\nPhone: "+phone);
	}
}

public class BankApplication {
    public static void main(String[] args) {
    Bank c1=new Bank("Mohan","85501289812","123456","9845234567");
    Bank c2=new Bank("Monisha","85501288765","234567","9092023098");
    Bank c3=new Bank("Mohan","85501288901","345678","7204645231");
    Bank c4=new Bank("Mohan","85501282345","4567891","8075765491");
    
    try {
		FileOutputStream fs=new FileOutputStream("bank.ser");
		ObjectOutputStream os=new ObjectOutputStream(fs);
		
		os.writeObject(c1);
		os.writeObject(c2);
		os.writeObject(c3);
		os.writeObject(c4);
		
	} catch (Exception e) {
		e.printStackTrace();
	}
    //c1=null;
    //c2=null;
    //c3=null;
    //c4=null;
   
    try {
		FileInputStream fs1=new FileInputStream("bank.ser");
		ObjectInputStream si=new ObjectInputStream(fs1);
		
		Bank c1R=(Bank)si.readObject();
		Bank c2R=(Bank)si.readObject();
		Bank c3R=(Bank)si.readObject();
		Bank c4R=(Bank)si.readObject();
		
		System.out.println("Customer 1 Info: ");
		c1R.display();
		System.out.println();
		System.out.println("Customer 2 Info: ");
		c2R.display();
		System.out.println();
		System.out.println("Customer 3 Info: ");
		c3R.display();
		System.out.println();
		System.out.println("Customer 4 Info: ");
		c4R.display();
		System.out.println();
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
    	
    }
}