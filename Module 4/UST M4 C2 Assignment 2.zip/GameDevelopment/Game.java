package GameDevelopment;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


class Level implements Serializable{
	private int level;
	private int score;
	public Level(int level,int score) {
		this.level=level;
		this.score=score;
	}
	public int getCurLevel() {
		return level;
	}
	public int getScore() {
		return score;
	}
}
class Achievement implements Serializable{
	private String achName;
	private boolean isUnlocked;
	public Achievement(String achName,boolean isUnlocked) {
		this.achName=achName;
		this.isUnlocked=isUnlocked;
	}
	public String getAchName() {
		return achName;
	}
	public boolean getIsUnlocked() {
		return isUnlocked;
	}
}

class Inventory implements Serializable{
	private String invName;
	private int qty;
	
	public Inventory(String invName,int qty) {
		this.invName=invName;
		this.qty=qty;
	}
	public String getInvName() {
		return invName;
	}
	public int getQty() {
		return qty;
	}
}

class GameState implements Serializable{
	private Level curlevel;
	private Achievement[] achievement;
	private Inventory inventory;
	
	public GameState(Level curlevel,Achievement[] achievement,Inventory inventory) {
		this.curlevel=curlevel;
		this.achievement=achievement;
		this.inventory=inventory;
	}
	public Level getLevel() {
		return curlevel;
	}
	public Achievement[] getAch() {
		return achievement;
	}
	public Inventory getInv() {
		return inventory;
	}
}

public class Game {

	//Serialize method
	public static void serialize(GameState gameState) {
		try {
			FileOutputStream fs=new FileOutputStream("NewGame.ser");
			ObjectOutputStream os=new ObjectOutputStream(fs);
			
			os.writeObject(gameState);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//Deserialize method
	public static GameState deserialize() {
		try {
			FileInputStream fs1=new FileInputStream("NewGame.ser");
			ObjectInputStream si=new ObjectInputStream(fs1);
			
			return(GameState)si.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static void main(String[] args) {
		Level L1=new Level(5,1360);
		Achievement[] A1={ new Achievement("Master of Levels",true), new Achievement("Collector",true) };
		Inventory I1=new Inventory("bomb",3);
		GameState G1=new GameState(L1,A1,I1);
		
		serialize(G1);
		GameState restored=deserialize();
		
		
		 System.out.println("Loaded Game State:");
	        System.out.print("Current Level: " + restored.getLevel().getCurLevel()+",");
	        System.out.println(" Score: " + restored.getLevel().getScore());
	        System.out.println("Achievements:");
	        for (Achievement achievement : restored.getAch()) {
	            System.out.print("- " + achievement.getAchName()+(":"));
	            System.out.println("- " + achievement.getIsUnlocked());
	        }
	        System.out.println("Player Inventory:");
	        System.out.print("- " + restored.getInv().getInvName()+":");
	        System.out.println("- " + restored.getInv().getQty());
	}
	}
