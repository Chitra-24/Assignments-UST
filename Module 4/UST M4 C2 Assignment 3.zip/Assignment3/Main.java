package Assignment3;
import java.io.*;
import java.net.*;

class Data implements Serializable {
    private String message;

    public Data(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}

public class Main {
    public static void main(String[] args) {
        // Start receiver and sender
        new Thread(Receiver::run).start();
        new Thread(Sender::run).start();
    }

    static class Sender {
        static void run() {
            try (Socket socket = new Socket("localhost", 12345);
                 ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream())) {

                Data data = new Data("Hello from Sender!");
                outputStream.writeObject(data);
                System.out.println("Message sent to receiver: " + data.getMessage());

            } catch (IOException e) {
                System.err.println("Error occurred while sending data: " + e.getMessage());
            }
        }
    }

    static class Receiver {
        static void run() {
            try (ServerSocket serverSocket = new ServerSocket(12345)) {
                System.out.println("Receiver waiting for sender...");
                Socket clientSocket = serverSocket.accept();
                System.out.println("Sender connected: " + clientSocket.getInetAddress());

                try (ObjectInputStream inputStream = new ObjectInputStream(clientSocket.getInputStream())) {
                    Data data = (Data) inputStream.readObject();
                    System.out.println("Received message from sender: " + data.getMessage());
                } catch (ClassNotFoundException e) {
                    System.err.println("Error occurred while deserializing data: " + e.getMessage());
                }

            } catch (IOException e) {
                System.err.println("Error occurred while receiving data: " + e.getMessage());
            }
        }
    }
}
