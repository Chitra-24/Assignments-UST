package com.lms;

public class NotEnoughBooksException extends Exception{
	public NotEnoughBooksException(String msg) {
		super(msg);
	}

}
