package com.oops;

abstract class Animal{
	public String name;
	
	public Animal(String name) {
		this.name = name;
	}

	abstract void makeSound();
}

class Dog extends Animal{
	public String category;
	public Dog(String name,String category) {
		super(name);
		this.category=category;
	}
	public void makeSound() {
		System.out.println(super.name+" Barks");
	}
}
class Cat extends Animal{
	public String category;
	public Cat(String name,String category) {
		super(name);
		this.category=category;
	}
	public void makeSound() {
		System.out.println(super.name+" Meow Meow");
	}
}
public class AbstractClass {

	public static void main(String[] args) {
		Cat cat=new Cat("Cat","Domestic animal");
		Dog dog=new Dog("Dog","Domestic animal");
		
		cat.makeSound();
		dog.makeSound();
	}

}
