package com.oops;
import java.lang.Math;
interface Shape{
	public double calculateArea();
	public void displayShapeInfo();
}

class Circle implements Shape{
	public int radius;
	public Circle(int radius) {
		this.radius = radius;
	}
	public double calculateArea() {
		double area=Math.PI*Math.pow(radius, 2);
		return area;
	}
	public void displayShapeInfo()
	{
		System.out.println("The radius of circle is : "+radius);
		System.out.println("Area of Cirle is : "+calculateArea());
	}
}

class Rectangle implements Shape{
	public int length;
	public int breadth;
	
	public Rectangle(int length, int breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}
	public double calculateArea() {
		double area=length*breadth;
		return area;
	}
	public void displayShapeInfo()
	{
		System.out.println("The Length of rectangle is : "+length);
		System.out.println("The Breadth of rectangle is : "+breadth);
		System.out.println("Area of Rectangle is : "+calculateArea());
	}
}
public class AbstractInterface {

	public static void main(String[] args) {
		Circle circle=new Circle(5);
		Rectangle rect=new Rectangle(7,8);
		
		System.out.println("Circle Info");
		circle.displayShapeInfo();
		System.out.println("\nRectangle Info");
		rect.displayShapeInfo();

	}

}
