package com.oops;

import java.util.Scanner;

interface Logger{
	public void logInfo();
	public void logError();
}
class FileLogger implements Logger{
	private String time;
	private String File;
	private char mode;

	
	public FileLogger(String time, String file, char mode) {
		this.time = time;
		File = file;
		this.mode = mode;
	}


	public String getTime() {
		return time;
	}


	public void setTime(String time) {
		this.time = time;
	}


	public String getFile() {
		return File;
	}


	public void setFile(String file) {
		File = file;
	}


	public char getMode() {
		return mode;
	}


	public void setMode(char mode) {
		this.mode = mode;
	}


	public void logInfo() {
		System.out.println(File+" opened");
		System.out.println("Time: "+time);
		System.out.println("Access mode: "+mode);
	}
	public void logError() {
		System.out.println("File could not be accessed");
	}
}

class DatabaseLogger implements Logger{
	private String time;
	private String database;

	

	public DatabaseLogger( String time, String database) {
		this.time = time;
		this.database = database;
	}


	public String getTime() {
		return time;
	}


	public void setTime(String time) {
		this.time = time;
	}


	public String getDatabase() {
		return database;
	}


	public void setDatabase(String database) {
		database = database;
	}


	public void logInfo() {
		System.out.println(database+" opened");
		System.out.println("Time: "+time);
	}
	public void logError() {
		System.out.println("Database could not be accessed");
	}
}

class Application {
    private Logger logger;

    public Application(Logger logger) {
        this.logger = logger;
    }

    public void performApplicationTask() {
        try {
            int result=1/5; 
            logger.logInfo();
        } catch (Exception e) {
            logger.logError();
        }
    }
}
public class EncapsulationInterface {

	public static void main(String[] args) {
		System.out.println("Using FileLogger:");
        Logger fileLogger = new FileLogger("12:45:23","prg.txt",'r');
        Application appWithFileLogger = new Application(fileLogger);
        appWithFileLogger.performApplicationTask();

        // Using DatabaseLogger
        System.out.println("\nUsing DatabaseLogger:");
        Logger databaseLogger = new DatabaseLogger("14:32:24","student database");
        Application appWithDbLogger = new Application(databaseLogger);
        appWithDbLogger.performApplicationTask();

	}

}
