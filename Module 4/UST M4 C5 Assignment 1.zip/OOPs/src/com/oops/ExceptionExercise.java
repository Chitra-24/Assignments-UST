package com.oops;

class InvalidDataException extends Exception {
 public InvalidDataException(String message) {
     super(message);
 }
}

class DataProcessor {
 public double processData(int[] data) throws InvalidDataException {
     if (data == null || data.length == 0) {
         throw new InvalidDataException("Array is empty or null.");
     }

     int sum = 0;
     for (int num : data) {
         sum += num;
     }

     return (double) sum / data.length;
 }
}

public class ExceptionExercise {
 public static void main(String[] args) {
     DataProcessor processor = new DataProcessor();

     try {
         int[] array1 = {1, 2, 3, 4, 5};
         double average1 = processor.processData(array1);
         System.out.println("Average of array1: " + average1);

         int[] array2 = {};
         double average2 = processor.processData(array2); // This will throw an exception
         System.out.println("Average of array2: " + average2);
     } catch (InvalidDataException e) {
         System.out.println("Error: " + e.getMessage());
     }
 }
}

