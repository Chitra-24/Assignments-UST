package com.oops;

class Vehicle{
	public String make;
	public String model;
	
	public Vehicle(String make, String model) {
		this.make = make;
		this.model = model;
	}
	public void startEngine() {
		System.out.println("Vehicle Class "+model+" Started");
	}
}

class Car extends Vehicle{
	public String cName;

	public Car(String make, String model, String cName) {
		super(make, model);
		this.cName = cName;
	}
	public void startEngine() {
		System.out.println(cName+" Started Moving");
	}
}

class MotorCycle extends Vehicle{
	public String mName;

	public MotorCycle(String make, String model, String mName) {
		super(make, model);
		this.mName = mName;
	}
	public void startEngine() {
		System.out.println(mName+" Started Moving");
	}
}
public class InheritancePolymorphism {
	public static void main(String args[]) {
		Car car=new Car("Honda","Honda Amaze","SUV");
		MotorCycle mcycle=new MotorCycle("Hero","Hero Splender","Splender");
		
		car.startEngine();
		mcycle.startEngine();
	}
}
