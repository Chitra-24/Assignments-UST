package com.Exceptions;

public class DivideByZeroExample {
	private static int divideNumbers(int numerator, int denominator) {
		return numerator/denominator;
	}

	public static void main(String[] args) {
		int numerator=10;
		int denominator=0;
		
		try {
			int result=divideNumbers(numerator,denominator);
			System.out.println("Result: "+result);
		}
		catch(ArithmeticException e) {
			e.printStackTrace();
			System.out.println("Number cannot be divisible by zero");
		}
	}

}
