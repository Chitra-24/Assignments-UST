package com.Exceptions;

public class ArrayIndexExample {

	public static void main(String[] args) throws Exception {
		int[] numbers= {1,2,3,4,5};
		try {
			int result=accessArrayElement(numbers,10);
			System.out.println("Result: "+result);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace(); // to mention clearly where the error is occurred.
			System.out.println("ArrayIndexOutOfBoundsException Caught: "+e.getMessage());
		}
	}

	private static int accessArrayElement(int[] array, int index)throws Exception {
		if(index<0 || index>=array.length) {
			throw new ArrayIndexOutOfBoundsException("Invlid array Index");
		}
		return array[index];
	}
}
