package com.threads;
//import java.util.Scanner;
class Callme{
	String eId;
	String eName;
	long salary;

	public void emp(String id,String n,long s) {
		eId=id;
		eName=n;
		salary=s;
		System.out.println("\nEMP ID:\t"+eId+"\nEMP NAME:\t"+eName+"\nEMP SALARY:\t"+salary);
	}
}
class EmployeeThread implements Runnable{
	Thread t;
	String name;
    String eID;
	long salary;
	String eName;
	Callme obj;
	
	public EmployeeThread(Callme o,String id,String n,long s,String tn) {
		name=tn;
		obj=o;
		eID=id;
		eName=n;
		salary=s;
		t=new Thread(this,name);
		t.start();
	}
	public void run() {
		synchronized(obj) {
		obj.emp(eID, eName, salary);
	}
	}
}
public class Employee {

	public static void main(String[] args) {
		Callme obj=new Callme();
		EmployeeThread e1=new EmployeeThread(obj,"E01","SHUBAM",15000,"Tone");
		EmployeeThread e2=new EmployeeThread(obj,"E02","SHEKAR",20000,"Ttwo");
		EmployeeThread e3=new EmployeeThread(obj,"E03","ANJALI",25000,"Tthree");

		try {
			e1.t.join();
			e2.t.join();
			e3.t.join();
		}catch(InterruptedException e) {
			System.out.println("Main Interrupted");
		}
		System.out.println("\nMain Existed");

	}
}
