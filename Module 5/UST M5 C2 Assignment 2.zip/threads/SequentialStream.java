package com.threads;

import java.util.List;
import java.util.concurrent.ForkJoinPool;

public class SequentialStream {
	public static final ForkJoinPool pool=new ForkJoinPool();
	public static final List<String> list=List.of("H","E","L","L","O");

	private static void Print(String s) {
		System.out.print(s+" ");
	}
	public static void sequentialExploration(List<String> item) {
		item.stream().forEach(SequentialStream::Print);
	}
	public static void main(String[] args) {
		sequentialExploration(list);

	}
}
