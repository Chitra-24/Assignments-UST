package com.threads;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class ParallelStream {
	public static final ForkJoinPool pool=new ForkJoinPool();
	public static final List<String> sList=List.of("H","E","L","L","O");
	public static final List<String> pList=List.of("W","O","R","L","D");
	
	private static void Print(String s) {
		System.out.print(s+" ");
		try {
            Thread.sleep(1000); 
        } catch (InterruptedException e) {
        	System.out.println("Interrupted");
        }
	}
	public static void sequentialExploration(List<String> item) {
		item.stream().forEach(ParallelStream::Print);
	}
	
	public static void parallelExploration(String s1) {
		System.out.print(s1+" ");
		try {
            Thread.sleep(1000); 
        } catch (InterruptedException e) {
        	System.out.println("Interrupted");
        }
	}
	
	public static void parallelTask(List<String> timeline) {
        ParallelExplorationTask task = new ParallelExplorationTask(timeline);
        pool.invoke(task);
    }
    static class ParallelExplorationTask extends RecursiveAction {
        private List<String> timeline;
        private static final int THRESHOLD = 2;
        public ParallelExplorationTask(List<String> timeline) {
            this.timeline = timeline;
        }

        protected void compute() {
        	if (timeline.size() <= THRESHOLD) {
                timeline.forEach(ParallelStream::parallelExploration);
        	}
        	else {
                int middle = timeline.size() / 2;
                List<String> leftSublist = timeline.subList(0, middle);
                List<String> rightSublist = timeline.subList(middle, timeline.size());
                ParallelExplorationTask leftTask = new ParallelExplorationTask(leftSublist);
                ParallelExplorationTask rightTask = new ParallelExplorationTask(rightSublist);
                invokeAll(leftTask, rightTask);
            } 
        }
    }
	public static void main(String[] args) {
		sequentialExploration(sList);
		parallelTask(pList);
	}
}