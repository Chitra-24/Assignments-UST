package com.threads;
import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.SubmissionPublisher;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Flow.*;

import com.threads.ParallelStream.ParallelExplorationTask;

public class ReactiveStream {

    private static final ForkJoinPool pool = new ForkJoinPool();

    private static final List<String> sequentialTimeline = List.of("H","E","L","L","O","-");
    private static final List<String> parallelTimelines = List.of("W","O","R","L","D");
    private static final SubmissionPublisher<String> publisher = new SubmissionPublisher<>();
    
  
    public static void main(String[] args) {
    	
        implementReactiveCommunication();
        
        //waitForCompletion();
    }
    


    private static void implementReactiveCommunication() {
        publisher.subscribe(new Subscriber<String>() {
            private Subscription subscription;
            

            @Override
            public void onSubscribe(Subscription subscription) {
                this.subscription = subscription;
                this.subscription.request(1); 
            }

            @Override
            public void onNext(String item) {
                System.out.println("Received event: " + item);
                subscription.request(1); 
            }

            @Override
            public void onError(Throwable throwable) {
                throwable.printStackTrace();
            }

            @Override
            public void onComplete() {
                System.out.println("Communication completed");
            }
            
        });
       
        	sequentialExploration(sequentialTimeline);
    	
        	parallelTask(parallelTimelines);
        	waitForCompletion();
        	
        	publisher.close();
    }
    
    public static void sequentialExploration(List<String> item) {
		item.stream().forEach(publisher::submit);
	}
    
    public static void parallelTask(List<String> timeline) {
        ParallelExplorationTask task = new ParallelExplorationTask(timeline);
        pool.invoke(task);
    }
    static class ParallelExplorationTask extends RecursiveAction {
        private List<String> timeline;
        private static final int THRESHOLD = 2;
        public ParallelExplorationTask(List<String> timeline) {
            this.timeline = timeline;
        }

        protected void compute() {
        	if (timeline.size() <= THRESHOLD) {
                timeline.forEach(publisher::submit);
        	}
        	else {
                int middle = timeline.size() / 2;
                List<String> leftSublist = timeline.subList(0, middle);
                List<String> rightSublist = timeline.subList(middle, timeline.size());
                ParallelExplorationTask leftTask = new ParallelExplorationTask(leftSublist);
                ParallelExplorationTask rightTask = new ParallelExplorationTask(rightSublist);
                invokeAll(leftTask, rightTask);
            } 
        }

    }
    private static void waitForCompletion() {
        try {
            Thread.sleep(5000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
