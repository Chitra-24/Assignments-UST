package com.threads;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class ThreadSynchronization {

	private static final Object sharedResource = new Object();
    public static final ForkJoinPool pool=new ForkJoinPool();
	public static final List<String> sList=List.of("H","E","L","L","O"," ");
	public static final List<String> pList=List.of("W","O","R","L","D");
    private static boolean explorationCompleted = false;

	
	private static void Print(String s) {
		System.out.print(s+" ");
		try {
            Thread.sleep(1000); 
        } catch (InterruptedException e) {
        	System.out.println("Interrupted");
        }
	}
	public static void sequentialExploration() {
		synchronized (sharedResource) {
		sList.stream().forEach(ThreadSynchronization::Print);
		explorationCompleted = true;
        sharedResource.notify();
		}
	}
	
	public static void parallelExploration(String s1) {
		System.out.print(s1+" ");
		try {
            Thread.sleep(1000); 
        } catch (InterruptedException e) {
        	System.out.println("Interrupted");
        }
	}
	
	public static void parallelTask() {
		synchronized (sharedResource) {
        ParallelExplorationTask task = new ParallelExplorationTask(pList);
        while(!explorationCompleted) {
        	 try {
                 sharedResource.wait();
             } catch (InterruptedException e) {
                 e.printStackTrace();
             	}
        	}
        pool.invoke(task);
		}
	}
    static class ParallelExplorationTask extends RecursiveAction {
        private List<String> timeline;
        private static final int THRESHOLD = 2;
        public ParallelExplorationTask(List<String> timeline) {
            this.timeline = timeline;
        }

        protected void compute() {
        	if (timeline.size() <= THRESHOLD) {
                timeline.forEach(ThreadSynchronization::parallelExploration);
        	}
        	else {
                int middle = timeline.size() / 2;
                List<String> leftSublist = timeline.subList(0, middle);
                List<String> rightSublist = timeline.subList(middle, timeline.size());
                ParallelExplorationTask leftTask = new ParallelExplorationTask(leftSublist);
                ParallelExplorationTask rightTask = new ParallelExplorationTask(rightSublist);
                invokeAll(leftTask, rightTask);
            } 
        }
    }
	public static void main(String[] args) {
		
		Thread sequentialExplorer = new Thread(ThreadSynchronization::sequentialExploration);
        sequentialExplorer.start();

        Thread parallelExplorer = new Thread(ThreadSynchronization::parallelTask);
        parallelExplorer.start();

        try {
            sequentialExplorer.join();
            parallelExplorer.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
	}
}
