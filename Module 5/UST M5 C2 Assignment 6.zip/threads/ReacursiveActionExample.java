package com.threads;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class ReacursiveActionExample {

    private static final ForkJoinPool pool = new ForkJoinPool();

    public static void main(String[] args) {
        pool.invoke(new InitializeTask());
    }

    static class InitializeTask extends RecursiveAction {
        protected void compute() {
            invokeAll(
                new InitializeSubtask("Task 1",5),
                new InitializeSubtask("Task 2",6),
                new InitializeSubtask("Task 3",7)
            );
        }
    }
    static class InitializeSubtask extends RecursiveAction {
        private final String taskName;
        private final int num;

        InitializeSubtask(String taskName,int num) {
            this.taskName = taskName;
            this.num=num;
        }
        protected void compute() {
        	//synchronized(pool) {
            System.out.println("Initializing " + taskName + "...");
            System.out.println("Initialization task " + taskName + " executed by thread: " + Thread.currentThread().getName());
            for(int i=1;i<=10;i++) {
            	System.out.println(num+"X"+i+"="+num*i);
            }
        }
    }
}
