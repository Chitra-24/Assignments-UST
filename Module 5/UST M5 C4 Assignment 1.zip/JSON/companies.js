const companies = require('./companies.json');
console.log("JSON TO JS FILE "+companies);
console.log(companies);


