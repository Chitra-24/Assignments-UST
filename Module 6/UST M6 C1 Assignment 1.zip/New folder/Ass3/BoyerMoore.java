package com.c1.Ass3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
public class BoyerMoore {
    public static void boyerMoore(String text, String pattern) {
    	boolean flag=false;
        int n = text.length();
        int m = pattern.length();

        int[] badChar = new int[256];
        Arrays.fill(badChar, -1);
        
        for (int i = 0; i < m; i++) {
            badChar[(int) pattern.charAt(i)] = i;
        }

        int s = 0; 
        while (s <= (n - m)) {
            int j = m - 1;
           
            while (j >= 0 && pattern.charAt(j) == text.charAt(s + j))
                j--;

            if (j < 0) {
            	flag=true;
                System.out.println("Pattern found at index " + s);
                s += (s + m < n) ? m - badChar[text.charAt(s + m)] : 1;
            } else {
                s += Math.max(1, j - badChar[text.charAt(s + j)]);
            }
        }
        if(flag==false) {
        	System.out.println("Not found!!");
        }
        
    }

    public static void main(String[] args) {
    	 try {
             BufferedReader innocentReader = new BufferedReader(new FileReader("C:\\Users\\chitr\\eclipse-workspace\\Module-6\\src\\com\\c1\\Ass3\\innocent_text.txt"));
             StringBuilder innocentText = new StringBuilder();
             String line;
             while ((line = innocentReader.readLine()) != null) {
                 innocentText.append(line);
             }
             innocentReader.close();

             BufferedReader messageReader = new BufferedReader(new FileReader("C:\\Users\\chitr\\eclipse-workspace\\Module-6\\src\\com\\c1\\Ass3\\message_to_find.txt"));
             StringBuilder message = new StringBuilder();
             while ((line = messageReader.readLine()) != null) {
                 message.append(line);
             }
             messageReader.close();

             boyerMoore(innocentText.toString(), message.toString());
         } catch (IOException e) {
             System.err.println("Error reading files: " + e.getMessage());
         }
    }
}
