package com.c1.Ass3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class KMP {

    public static void kmpSearch(String text, String pattern) {
    	boolean flag=false;
        int[] lps = computeLPSArray(pattern);
        int n = text.length();
        int m = pattern.length();
        int i = 0; 
        int j = 0; 

        while (i < n) {
            if (pattern.charAt(j) == text.charAt(i)) {
                i++;
                j++;
            }
            if (j == m) {
            	flag=true;
                System.out.println("Pattern found at index " + (i - j));
                j = lps[j - 1];
            } else if (i < n && pattern.charAt(j) != text.charAt(i)) {
                if (j != 0)
                    j = lps[j - 1];
                else
                    i = i + 1;
            }
        }
        if(flag==false) {
        	System.out.println("Not found!!");
        }
    }

    public static int[] computeLPSArray(String pattern) {
        int m = pattern.length();
        int[] lps = new int[m];
        int len = 0;
        int i = 1;
        lps[0] = 0;

        while (i < m) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = len;
                    i++;
                }
            }
        }
        return lps;
    }

    public static void main(String[] args) {
    	try {
            BufferedReader innocentReader = new BufferedReader(new FileReader("C:\\Users\\chitr\\eclipse-workspace\\Module-6\\src\\com\\c1\\Ass3\\innocent_text.txt"));
            StringBuilder innocentText = new StringBuilder();
            String line;
            while ((line = innocentReader.readLine()) != null) {
                innocentText.append(line);
            }
            innocentReader.close();

            BufferedReader messageReader = new BufferedReader(new FileReader("C:\\Users\\chitr\\eclipse-workspace\\Module-6\\src\\com\\c1\\Ass3\\message_to_find.txt"));
            StringBuilder message = new StringBuilder();
            while ((line = messageReader.readLine()) != null) {
                message.append(line);
            }
            messageReader.close();

            kmpSearch(innocentText.toString(), message.toString());
        } catch (IOException e) {
            System.err.println("Error reading files: " + e.getMessage());
        }
   }
}