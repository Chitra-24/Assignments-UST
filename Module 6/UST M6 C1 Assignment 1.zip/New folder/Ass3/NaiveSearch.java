package com.c1.Ass3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class NaiveSearch {
    
    public static void main(String[] args) {
        try {
            BufferedReader innocentReader = new BufferedReader(new FileReader("C:\\Users\\chitr\\eclipse-workspace\\Module-6\\src\\com\\c1\\Ass3\\innocent_text.txt"));
            StringBuilder innocentText = new StringBuilder();
            String line;
            while ((line = innocentReader.readLine()) != null) {
                innocentText.append(line);
            }
            innocentReader.close();

            BufferedReader messageReader = new BufferedReader(new FileReader("C:\\Users\\chitr\\eclipse-workspace\\Module-6\\src\\com\\c1\\Ass3\\message_to_find.txt"));
            StringBuilder message = new StringBuilder();
            while ((line = messageReader.readLine()) != null) {
                message.append(line);
            }
            messageReader.close();

            naiveSearch(innocentText.toString(), message.toString());
        } catch (IOException e) {
            System.err.println("Error reading files: " + e.getMessage());
        }
    }

    public static void naiveSearch(String text, String pattern) {
    	boolean flag=false;
        int n = text.length();
        int m = pattern.length();

        for (int i = 0; i <= n - m; i++) {
            int j;
            for (j = 0; j < m; j++) {
                if (text.charAt(i + j) != pattern.charAt(j)) {
                    break;
                }
            }
            if (j == m) {
            	flag=true;
                System.out.println("Pattern found at index " + i);
            }
        }
        if(flag!=true) {
        	System.out.println("Not found!!");
        }
    }
}

