package com.course_1;

import java.util.Arrays;
import java.util.Scanner;

public class BubbleSort {
	static int temp;
	static void sortingBubble(int N,int[] Arr) {
		for(int i=0;i<N-1;i++) {
			for(int j=0;j<N-1;j++) {
				if(Arr[j]>Arr[j+1]) {
					temp=Arr[j];
					Arr[j]=Arr[j+1];
					Arr[j+1]=temp;
				}
			}
		}
		System.out.println(Arrays.toString(Arr));
	}

	public static void main(String[] args) {
		int arrSize;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the array size");
		arrSize=sc.nextInt();
		int[] arr=new int[arrSize];
		System.out.println("enter array elements");
		for(int i=0;i<arrSize;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Before Sorting");
		System.out.println(Arrays.toString(arr));
		System.out.println("After Sorting");
		sortingBubble(arrSize,arr);
		
		
	}

}
