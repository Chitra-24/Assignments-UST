package com.Museum;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Exhibit {
    private String name;
    private int id;

    public Exhibit(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }
}


class MuseumLayout {
    private Exhibit[] exhibits;
    private int[][] distances;

    public MuseumLayout(Exhibit[] exhibits) {
        this.exhibits = exhibits;
        this.distances = new int[exhibits.length][exhibits.length];
    }

    public void addDistance(int fromId, int toId, int distance) {
        distances[fromId][toId] = distance;
        distances[toId][fromId] = distance; 
    }

    public int getDistance(int fromId, int toId) {
        return distances[fromId][toId];
    }

    public Exhibit getExhibitById(int id) {
        for (Exhibit exhibit : exhibits) {
            if (exhibit.getId() == id) {
                return exhibit;
            }
        }
        return null; 
    }

	public int getNumExhibits() {
		return exhibits.length;
	}
}

public class MuseumTourPlanner {
    private MuseumLayout layout;

    public MuseumTourPlanner(MuseumLayout layout) {
        this.layout = layout;
    }

    public List<Exhibit> planTour(Exhibit startExhibit, List<Exhibit> desiredExhibits) {
        int numExhibits = layout.getNumExhibits();
        boolean[] visited = new boolean[numExhibits];
        int[] distances = new int[numExhibits];
        Arrays.fill(distances, Integer.MAX_VALUE);

        int startId = startExhibit.getId();
        distances[startId] = 0;

        while (true) {
            int closestId = -1;
            int closestDistance = Integer.MAX_VALUE;

            for (int i = 0; i < numExhibits; i++) {
                if (!visited[i] && distances[i] < closestDistance) {
                    closestId = i;
                    closestDistance = distances[i];
                }
            }

            if (closestId == -1) {
                break; 
            }

            visited[closestId] = true;

            for (int i = 0; i < numExhibits; i++) {
                if (!visited[i] && layout.getDistance(closestId, i) != 0) {
                    int newDistance = distances[closestId] + layout.getDistance(closestId, i);
                    if (newDistance < distances[i]) {
                        distances[i] = newDistance;
                    }
                }
            }
        }

        List<Exhibit> tourPath = new ArrayList<>();
        for (Exhibit exhibit : desiredExhibits) {
            tourPath.add(exhibit);
        }

        return tourPath;
    }
    public static void main(String[] args) {
        Exhibit[] artMuseumExhibits = {
            new Exhibit("Monet's Water Lilies", 1),
            new Exhibit("Michelangelo's Pieta", 2),
            new Exhibit("Egyptian Sarcophagi", 3),
            new Exhibit("Picasso's Guernica", 4),
            new Exhibit("Van Gogh's Sunflowers", 5)
        };

        Exhibit[] scienceMuseumExhibits = {
            new Exhibit("Space Exploration Exhibit", 1),
            new Exhibit("Dinosaur Skeletons", 2),
            new Exhibit("The Human Body", 3),
            new Exhibit("Interactive Robot Display", 4),
            new Exhibit("Weather Phenomena Simulator", 5)
        };

        Exhibit[] historyMuseumExhibits = {
            new Exhibit("Medieval Armor Collection", 1),
            new Exhibit("Ancient Roman Ruins", 2),
            new Exhibit("Interactive Timeline of US History", 3),
            new Exhibit("Silk Road Trade Routes Exhibit", 4),
            new Exhibit("Egyptian Mummies and Hieroglyphics", 5)
        };

        MuseumLayout artMuseumLayout = new MuseumLayout(artMuseumExhibits);
        MuseumLayout scienceMuseumLayout = new MuseumLayout(scienceMuseumExhibits);
        MuseumLayout historyMuseumLayout = new MuseumLayout(historyMuseumExhibits);

        artMuseumLayout.addDistance(1, 2, 10);
        artMuseumLayout.addDistance(1, 3, 15);
       
        Exhibit exhibit1 = artMuseumLayout.getExhibitById(1);
        Exhibit exhibit2 = artMuseumLayout.getExhibitById(3);
        int distance = artMuseumLayout.getDistance(1, 2);
        System.out.println("Distance between " + exhibit1.getName() + " and " + exhibit2.getName() + " is " + distance + " minutes.");
    }
}









