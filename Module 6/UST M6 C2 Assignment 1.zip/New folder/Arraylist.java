package com.c2.DS;

import java.util.ArrayList;
import java.util.Iterator;

public class Arraylist {

	public static void main(String[] args) {
		ArrayList<String> names=new ArrayList<>();
		names.add("Ram");
		names.add("Annu");
		names.add("Suma");
		names.add(2,"Pooja");
		
		System.out.println(names.toString());
		
		names.remove(1);
		
		System.out.println("\nList after removing:");
		Iterator<String> data=names.iterator();
		while(data.hasNext()) {
			System.out.println(data.next());
		}
	}

}
