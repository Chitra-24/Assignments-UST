package com.c2.DS;

import java.util.Scanner;

public class BinarySearch {

	static int binarySearch(int[] arr,int key,int low,int high) {
		int mid=(low+high)/2;
		while(low<=high) {
			if(key==arr[mid]) {
				return mid;
			}
			else if(key<arr[mid]) {
				return binarySearch(arr,key,low,mid-1);
			}
			else {
			return binarySearch(arr,key,mid+1,high);
		}
		}
		return -1;
	}
	public static void main(String[] args) {
		int[] array={10,20,24,28,35,39,40};
		int size=array.length;
		int l=0;
		int h=array.length-1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the key to find");
		int keyValue=sc.nextInt();
		int res=binarySearch(array,keyValue,l,h);
		System.out.println("key found at index: "+res);
	}

}
