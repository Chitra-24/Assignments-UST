package com.c2.DS;

class field { 
	int data; 
	field next;  
	field(int value) 
	{ 
		data = value; 
		next = null; 
	} 
} 

public class CircularLL { 
	static field head = null; 
	static field tail = null; 
	static void insertAtBeginning(int data) 
	{ 
		field temp = new field(data); 
		if (head == null) { 
			head = temp; 
			tail = temp; 
		} 
		else { 
			temp.next = head; 
			head = temp; 
			tail.next=head;
		} 
	} 

	static void insertAtEnd(int data) 
	{ 
		field temp = new field(data); 
		if (tail == null) { 
			head = temp; 
			tail = temp; 
		} 
		else { 
			tail.next = temp; 
			tail = temp; 
			tail.next=head;
		} 
	} 

	static void deleteAtBeginning() 
	{ 
		if (head == null) { 
			return; 
		} 

		if (head == tail) { 
			head = null; 
			tail = null; 
			return; 
		} 

		field temp = head; 
		head = head.next; 
		temp.next = head; 
	} 

	static void deleteAtEnd() 
	{ 
		if (tail == null) { 
			return; 
		} 

		if (head == tail) { 
			head = null; 
			tail = null; 
			return; 
		} 

		field temp = head; 
		while (temp.next.next != head) {
            temp = temp.next;
        }
		tail=temp;
        tail.next = head;
	} 

	static void display(field head) 
	{ 
		field temp = head; 
		while (temp != null) { 
			System.out.print(temp.data + " "); 
			temp = temp.next; 
		} 
		System.out.println("NULL"); 
	} 
	public static void main(String[] args) 
	{ 
		insertAtEnd(1); 
		insertAtEnd(2); 
		insertAtEnd(3); 
		insertAtEnd(4); 
		insertAtEnd(5); 

		System.out.print("After insertion at tail: "); 
		display(head); 

		System.out.print("After insertion at head: "); 
		insertAtBeginning(0); 
		display(head);  

		deleteAtBeginning(); 
		System.out.print("After deletion at the beginning: "); 
		display(head); 

		deleteAtEnd(); 
		System.out.print("After deletion at the end: "); 
		display(head); 

	} 
}

