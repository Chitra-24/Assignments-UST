package com.c2.DS;

import java.util.LinkedList;

class Hotel {
    private String name;
    private int stars;

    public Hotel(String name, int stars) {
        this.name = name;
        this.stars = stars;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
this.stars = stars;
    }

    @Override
    public String toString() {
        return "Hotel{" + "name='" + name + '\'' + ", stars=" + stars + '}';
    }
}

public class Linkedlist {
	static LinkedList<Hotel> hotels = new LinkedList<>();
	static void addAtBeg(String name,int star) {
		 hotels.addFirst(new Hotel(name,star));
	}
	static void addAtEnd(String name,int star) {
		 hotels.addLast(new Hotel(name,star));
	}
	static void deleteAtBeg() {
		 hotels.removeFirst();
	}
	static void deleteAtEnd() {
		 hotels.removeLast();
	}
	static void deleteAtPos(int pos) {
		int count=0;
		for (Hotel hotel : hotels) {
			count++;
			if(count==pos) {
				hotels.remove(hotel);
				break;
			}
        }
	}
	static void view() {
		for (Hotel hotel : hotels) {
            System.out.println(hotel);
        }
	}
    public static void main(String[] args) {
        //LinkedList<Hotel> hotels = new LinkedList<>();

        hotels.add(new Hotel("Taj", 5));
        hotels.add(new Hotel("Oberoi", 5));
        hotels.add(new Hotel("Marriott", 4));

        System.out.println("\nHotels:");
        view();

        addAtBeg("Shangri-La", 5);
        addAtEnd("Ibis", 2);
        
        System.out.println("\nHotels after adding hotels:");
        view();
        deleteAtEnd();
        System.out.println("\nHotels after removing hotels:");
        view();
        System.out.println("\nHotels after removing from position 3 hotels:");
        deleteAtPos(3);
        view();
 
        Hotel firstHotel = hotels.getFirst();
        System.out.println("\nFirst hotel of the linked list: " + firstHotel);
        Hotel lastHotel = hotels.getLast();
        System.out.println("\nLast hotel of the linked list: " + lastHotel);


       
    }
}