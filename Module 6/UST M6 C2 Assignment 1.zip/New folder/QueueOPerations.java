package com.c2.DS;

import java.util.LinkedList;
import java.util.Queue;

public class QueueOPerations {

	    public static void main(String[] args) {
	        Queue<String> queue = new LinkedList<>();

	        queue.add("Pune");
	        queue.add("Mumbai");
	        queue.add("Nashik");

	        System.out.println("Size of the queue: " + queue.size());
	        System.out.println("Stack items:");
	        for (String q : queue) {
	            System.out.println(q);
	        }
	        
	        System.out.println("Removed elements:");
	        while (!queue.isEmpty()) {
	            System.out.println(queue.poll());
	        }
	    }
}
