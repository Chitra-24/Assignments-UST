package com.c2.DS;

import java.util.Stack;

public class StackOperations {
	    public static void main(String[] args) {
	        Stack<String> stack = new Stack<>();

	        stack.push("Lion");
	        stack.push("Tiger");
	        stack.push("Elephant");

	        System.out.println("Stack items:");
	        for (String s : stack) {
	            System.out.println(s);
	        }
	        
	        System.out.println("Top of the stack is: ");
	        System.out.println(stack.peek());
	        
	        System.out.println("Popped item:");
	        while (!stack.empty()) {
	            System.out.println(stack.pop());
	        }
	    }
}
