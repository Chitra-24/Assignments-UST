package com.DataStructure.Algorithm;

import java.util.Arrays;

public class Sorting {

	public static int[] bubbleSort(int[] array) {
		int size=array.length;
		int temp;
		for(int i=0;i<size-1;i++) {
			for(int j=0;j<size-1;j++) {
				if(array[j]>array[j+1]) {
					temp=array[j];
					array[j]=array[j+1];
					array[j+1]=temp;
				}
			}
		}
		return array;
	}
	
	public static void selectionSort(int[] array) {
		int size=array.length;
		for(int i=0;i<size-1;i++) {
			int min=i;
			for(int j=i+1;j<size;j++) {
				if(array[min]>array[j]) {
					min=j;
				}
			}
			if(min!=i) {
				int temp=array[i];
				array[i]=array[min];
				array[min]=temp;
			}
		}
		System.out.println(Arrays.toString(array));
	}
	
	public static void insertionSort(char[] arr) {
		int j;
		int size=arr.length;
		for(int i=1;i<size;i++) {
			char temp=arr[i];
			j=i-1;
			while(j>=0 && arr[j]>temp) {
				arr[j+1]=arr[j];
				j--;
			}
			arr[j+1]=temp;
		}
		System.out.println(Arrays.toString(arr));
	}
	public static void main(String[] args) {
	int[] arr= {15,6,16,8,5};
	int[] arr1= {7,4,10,8,3,1};
	char[] str= {'i','a','e','u','o'};
	System.out.println("Sorted using Bubble sort");
	int[] res=bubbleSort(arr);
	System.out.println(Arrays.toString(res));
	System.out.println("Sorted using Selection sort");
	selectionSort(arr1);
	System.out.println("Sorted using insertion sort");
	insertionSort(str);
	}

}
