package com.DataStructure.Algorithm;
//task 2
import java.lang.String;
public class StringOPerations {

	public static void main(String[] args) {
		String str="the Caressing Wind";
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		System.out.println(str.length());
		System.out.println(str.charAt(6));
		System.out.println(str.substring(3,8));
	}

}
