package com.DataStructure.Algorithm;
//task 1
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class StringSearch {

	public static void search(String text, String pattern) {
    	boolean flag=false;
        int n = text.length();
        int m = pattern.length();

        for (int i = 0; i <= n - m; i++) {
            int j;
            for (j = 0; j < m; j++) {
                if (text.charAt(i + j) != pattern.charAt(j)) {
                    break;
                }
            }
            if (j == m) {
            	flag=true;
                System.out.println("Pattern found at index " + i);
            }
        }
        if(flag!=true) {
        	System.out.println("Not found!!");
        }
    }
	public static void main(String[] args) {
		try {
			String Text="";
			FileReader file=new FileReader(new File("C:\\Users\\chitr\\eclipse-workspace\\Module-6\\src\\com\\DataStructure\\Algorithm\\Text.txt"));
			Scanner scan=new Scanner(file);
			while(scan.hasNextLine()) {
				Text+=scan.next();
				//System.out.println(Text);
			}
			String pattern="came";
			search(Text,pattern);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
