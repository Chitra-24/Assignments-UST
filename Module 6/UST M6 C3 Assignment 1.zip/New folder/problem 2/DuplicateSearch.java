package com.DataStructure.Algorithm;

public class DuplicateSearch {

	public static void main(String[] args) {
	int[] arr= {4,20,87,90,58,66,33,65,25,66};
	boolean flag=false;
	
	for (int i = 0; i < arr.length; i++) {
		for (int j = 0; j < arr.length; j++) {
			if (i != j && arr[i] == arr[j]) {
				System.out.println("Duplicate value found: " + arr[i]);
				flag=true;
				break;
			}
		}
		if(flag==true) {
			break;
		}
	}
	if(flag==false) {
		System.out.println("No duplicate value found.");
		}
	}
}
