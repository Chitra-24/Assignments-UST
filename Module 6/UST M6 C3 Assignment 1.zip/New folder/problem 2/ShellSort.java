package com.DataStructure.Algorithm;

public class ShellSort {

    static void sort(int arr[]) {
        int n = arr.length;

        for (int i = n / 2; i > 0; i /= 2) {
            for (int j = i; j < n; j += 1) {
                int temp = arr[j];
                int k;

                for (k = j - i; k >= 0 && arr[k] > temp; k -= i) {
                    arr[k + i] = arr[k];
                }

                arr[k + i] = temp;
            }
        }
    }

    static void printArray(int arr[]) {
        int n = arr.length;
        for (int i = 0; i < n; ++i)
            System.out.print(arr[i] + " ");
        System.out.println();
    }

    public static void main(String args[]) {
        int arr[] = { 10, 7, 8, 9, 1, 5, 12, 6 };

        System.out.println("Given array is");
        printArray(arr);
        sort(arr);
        System.out.println("\nSorted array is");
        printArray(arr);
    }
}
