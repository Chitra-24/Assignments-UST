package com.DataStructure.Algorithm;

import java.util.Random;
import java.util.Scanner;

public class StudentGrading {

	public static void main(String[] args) {
		int[][] marks= {{4001,78,90,100,62},
						{4002,65,81,92,93},
						{4003,88,92,74,87}};
		int row=marks.length;
		int col=marks[0].length;
		
		System.out.println("ID\tsub1\tsub2\tsub3\tsub4");
		for(int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
				System.out.print(marks[i][j]+"\t");
			}
			System.out.println();
		}
		Random r=new Random();
		int row1=r.nextInt(row);
		float avg;
		int sum=0;
		for(int j=1;j<col;j++) {
			sum+=marks[row1][j];
		}
		avg=sum/col-1;
		System.out.println("Average of "+marks[row1][0]+" is "+avg);
	}
}
