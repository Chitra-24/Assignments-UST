package com.DataStructure.Algorithm;

class field{
	String name;
	field prev;
	field next;
	public field(String name) {
		prev=null;
		next=null;
		this.name = name;
	}
	
}

class DLL{
	field head;
	
	public void append(String value) {
		field temp=new field(value);
		if(head==null) {
			head=temp;
			temp.prev=null;
			return;
		}
		field cur=head;
		while(cur.next!=null) {
			cur=cur.next;
		}
		cur.next=temp;
		temp.prev=cur;
	}
	
	public void delete(String data) {
	    if (head == null) {
	        System.out.println("List is empty");
	        return;
	    }
	    field curr = head;
	    while (curr != null) {
	        if (curr.name == data) {
	            if (curr.prev != null) {
	                curr.prev.next = curr.next;
	            } else {
	                head = curr.next;
	            }
	            if (curr.next != null) {
	                curr.next.prev = curr.prev;
	            } 
	            return;
	        }
	        curr = curr.next;
	    }
	    System.out.println("Element not found");
	}
	public void display() {
		field currentNode=head;
		while (currentNode != null) {
			System.out.print(currentNode.name + "\t");
			currentNode = currentNode.next;
			}
			System.out.println();
	}
}
public class DLLDemo {

	public static void main(String[] args) {
		DLL ll=new DLL();
		ll.append("sam");
		ll.append("Mohan");
		ll.append("Lucy");
		ll.append("Tom");
		ll.display();
		ll.delete("Lucy");
		System.out.println("\nAfter deleting:");
		ll.display();
		
	}

}

