package com.DataStructure.Algorithm;
import java.util.ListIterator;
import java.util.Collections;
import java.util.LinkedList;

public class LIterator {

	public static void main(String[] args) {
		LinkedList<Integer> LL=new LinkedList<>();
		LL.add(3);
		LL.add(19);
		LL.add(33);
		LL.add(2);
		
		LL.addFirst(20);
		LL.addLast(25);
		ListIterator l=LL.listIterator();
		while(l.hasNext()) {
			System.out.print(l.next()+" ");
		}
		Collections.sort(LL);
		System.out.println("\nSorted List\n"+LL);
	}

}
