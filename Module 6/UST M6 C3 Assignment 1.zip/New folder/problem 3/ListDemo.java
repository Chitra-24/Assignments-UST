package com.DataStructure.Algorithm;

class Node{
	Node next;
	String name;

	Node(String name) {
		this.name = name; 
	}
}

class List {
	Node head;
	
	public void appendList(String name) {
		if (head == null) {
			head = new Node(name) ;
			return;
		}
			Node currentNode = head;
			while (currentNode.next != null) {
				currentNode = currentNode.next;
			}
				currentNode.next = new Node(name);
			}
	public int indexOf(String characterName) {
		Node cNode = head;
		int cIndex = 0;
		while (cNode.next != null) {
			if (cNode.name.equals(characterName) ) {
				return cIndex;
			} 
			else {
				cNode = cNode.next;
				cIndex += 1;
			}
		}
		return -1;
	}
}
public class ListDemo {
public static void main(String[] args) {
	List studentList = new List();
	studentList.appendList("Sebastian");
	studentList.appendList("Lucy");
	studentList.appendList("Pat");
	studentList.appendList("Kyle");
	
	System.out.print("List -> ");
		Node currentNode = studentList.head;
		while (currentNode != null) {
		System.out.print(currentNode.name + "\t");
		currentNode = currentNode.next;
		}
		System.out.println();
		
		System.out.print("index of Pat is ");
		System.out.println(studentList.indexOf("Pat"));
}
}
