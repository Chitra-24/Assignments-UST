package com.DataStructure.Algorithm;

import java.util.Map.Entry;
import java.util.*;
import java.util.List;

public class HashMapDemo {
	public static void main(String[] args) {
		Map<String,Integer> hash=new HashMap<>();
		
		hash.put("Math",89);
		hash.put("Eng",94);
		hash.put("Hindi",90);
		hash.put("Science", 92);
		hash.put("civil",87);
		hash.put("Chemistry", 85);
		
		System.out.println(hash);

		String key="civil";
		if(hash.containsKey(key)) {
			System.out.println(key+" marks is "+hash.get(key));
		}
		else {
			System.out.println("Not found");
		}
		
		int value=85;
		if(hash.containsValue(value)) {
			System.out.println(value +" found");
		}
		else {
			System.out.println("Not found");
		}
		System.out.println("\nMap Entries");
		Set<Entry<String, Integer>> en = hash.entrySet();
		for(Map.Entry<String,Integer> e: hash.entrySet()) {
			System.out.println(e.getKey()+" "+e.getValue());
		}
		//Sorting by keys
		/*TreeMap<String, Integer> sorted=new TreeMap<String, Integer>(hash);
		for(Map.Entry<String,Integer> e: sorted.entrySet()) {
			System.out.println(e.getKey()+" "+e.getValue());
		}*/
		
		Comparator<Entry<String, Integer>> valueComparator = (e1, e2) -> {
			Integer v1 = e1.getValue();
			Integer v2 = e2.getValue();
			return v1.compareTo(v2);
		};
			List<Entry<String, Integer>> listOfEntries = new ArrayList(en);
			Collections.sort(listOfEntries, valueComparator);

			LinkedHashMap<String, Integer> sortedByValue = new LinkedHashMap<>(listOfEntries.size());

			for(Entry<String, Integer> entry : listOfEntries){
			sortedByValue.put(entry.getKey(), entry.getValue());
		}
			System.out.println("\nAfter sorting by value");
			for(Map.Entry<String,Integer> e: hash.entrySet()) {
				System.out.println(e.getKey()+" "+e.getValue());
			}
	}
}
