package com.DataStructure.Algorithm;

import java.util.LinkedList;

class NetworkGraph {
	int Vertex;
	LinkedList<Integer> myNetwork[]; 

	NetworkGraph(int Vertex) {
		this. Vertex = Vertex;
		myNetwork = new LinkedList[Vertex];
		for (int i = 0; i < Vertex; i++) {
			myNetwork[i] = new LinkedList<>();
		}
	}

	 void addVertexEdge(int edgeStart, int edgeEnd) {
		 myNetwork[edgeStart].add(edgeEnd);
		 myNetwork[edgeEnd].add(edgeStart);
}
	 void outputGraph(NetworkGraph myGraph) {
		 System.out.println("\nVertex");
		 System.out.println("Vertices\tEdeges") ;
		 for (int i = 0; i < myGraph.Vertex; i++) {
		 System.out.print(i + "\t");
		 for (Integer transverseGraph : myGraph.myNetwork[i]) {
		 System.out.print(" -> " + transverseGraph);
		 }
		 System.out.println();
		 }
	}
}
public class GraphDemo {

	public static void main(String[] args) {
		int Vertex = 9; 
		NetworkGraph myGraph = new NetworkGraph(Vertex);
		myGraph.addVertexEdge( 0, 3);
		myGraph.addVertexEdge( 0, 4);
		myGraph.addVertexEdge( 0, 7);
		myGraph.addVertexEdge( 1, 2);
		myGraph.addVertexEdge( 1, 3);
		myGraph.addVertexEdge( 1, 5);
		myGraph.addVertexEdge( 1, 8);
		myGraph.addVertexEdge( 5, 2);
		myGraph.addVertexEdge( 6, 7);
		myGraph.addVertexEdge( 6, 8);
		myGraph.addVertexEdge( 6, 0);
		
		myGraph.outputGraph(myGraph);
	}

}
