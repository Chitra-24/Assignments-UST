package com.course_3;

import java.util.Arrays;

public class BubbleSort {

	public static int[] bubbleSort(int[] array) {
		int size=array.length;
		int temp;
		for(int i=0;i<size-1;i++) {
			for(int j=0;j<size-1;j++) {
				if(array[j]>array[j+1]) {
					temp=array[j];
					array[j]=array[j+1];
					array[j+1]=temp;
				}
			}
		}
		return array;
	}
	public static void main(String[] args) {
		int[] arr= {15,6,16,8,5};
		System.out.println("Sorted using Bubble sort");
		int[] res=bubbleSort(arr);
		System.out.println(Arrays.toString(res));

	}

}
