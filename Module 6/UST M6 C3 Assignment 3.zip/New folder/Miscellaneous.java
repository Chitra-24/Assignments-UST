package com.course_3;

public class Miscellaneous {

	    public static int interpolationSearch(int[] arr, int key) {
	        int low = 0;
	        int high = arr.length - 1;

	        while (low <= high && key >= arr[low] && key <= arr[high]) {
	            if (low == high) {
	                if (arr[low] == key)
	                    return low;
	                return -1;
	            }
	            int pos = low + ((key - arr[low]) * (high - low)) / (arr[high] - arr[low]);
	            if (arr[pos] == key)
	                return pos;
	            else if (arr[pos] < key)
	                low = pos + 1;
	            else
	                high = pos - 1;
	        }
	        return -1; 
	    }
	    public static int exponentialSearch(int[] arr, int key) {
	        int n = arr.length;
	        if (arr[0] == key)
	            return 0;
	        int i = 1;
	        while (i < n && arr[i] <= key)
	            i *= 2;
	        return binarySearch(arr, key, i / 2, Math.min(i, n - 1));
	    }
	    public static int binarySearch(int[] arr, int key, int low, int high) {
	        while (low <= high) {
	            int mid = low + (high - low) / 2;
	            if (arr[mid] == key)
	                return mid;
	            else if (arr[mid] < key)
	                low = mid + 1;
	            else
	                high = mid - 1;
	        }
	        return -1; 
	    }
	public static void main(String[] args) {
		int[] arr = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        int key = 60;
        int index = interpolationSearch(arr, key);
        if (index != -1)
            System.out.println("Element found at index " + index);
        else
            System.out.println("Element not found");
        
        System.out.println("Exponential Serach");
        int index1 = exponentialSearch(arr, key);
        if (index != -1)
            System.out.println("Element found at index " + index);
        else
            System.out.println("Element not found");

	}

}
