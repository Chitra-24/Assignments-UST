package com.course_3;

import java.util.ArrayList;
import java.util.HashMap;

class Graph {
    private final int V; 
    private final ArrayList<ArrayList<Integer>> adjList;
    private final int[][] adjMatrix;

    public Graph(int V) {
        this.V = V;
        adjList = new ArrayList<>();
        adjMatrix = new int[V][V];
        // Initialize adjacency list
        for (int i = 0; i < V; i++) {
            adjList.add(new ArrayList<>());
        }
    }
    public void addEdge(int u, int v) {
        // Add edge to adjacency list
        adjList.get(u).add(v);
        adjList.get(v).add(u);

        // Add edge to adjacency matrix
        adjMatrix[u][v] = 1;
        adjMatrix[v][u] = 1;
    }

    public void printAdjList() {
        System.out.println("\nAdjacency List:");
        for (int i = 0; i < V; i++) {
            System.out.print("Vertex " + i + " -> ");
            for (int v : adjList.get(i)) {
                System.out.print(v + " ");
            }
            System.out.println();
        }
        System.out.println();
    }

    public void printAdjMatrix() {
        System.out.println("Adjacency Matrix:");
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                System.out.print(adjMatrix[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
}

public class SearchingAlgo {

	public static void hashFunctions(){
        HashMap<String,Integer> map = new HashMap<>();
        map.put("India",91);
        map.put("USA",1);
        map.put("Russia",7);
        map.put("Italy",39);

        System.out.println(map.get("Russia"));
        System.out.println(map.containsKey("Saudi"));
        System.out.println(map.getOrDefault("China", 86));
        map.put("Israel",972);
        for(String s:map.keySet()){
            System.out.println(s+"\t"+map.get(s));
        }
        map.remove("Israel");
        for(String s:map.keySet()){
            System.out.println(s+"\t"+map.get(s));
        }
    }
	public static void main(String[] args) {
		 Graph graph = new Graph(5);
	        graph.addEdge(0, 1);
	        graph.addEdge(0, 4);
	        graph.addEdge(1, 2);
	        graph.addEdge(1, 3);
	        graph.addEdge(1, 4);
	        graph.addEdge(2, 3);
	        graph.addEdge(3, 4);

	        graph.printAdjList();
	        graph.printAdjMatrix();
	        System.out.println("Hash Funtion\n");
	        hashFunctions();
	}

}
