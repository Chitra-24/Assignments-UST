package com.DataStructure.Algorithm;

import java.util.Iterator;
import java.util.LinkedList;

class TraverseDemo {
	private int Vertex; 
	private LinkedList<Integer> adjacencyList[];
	public TraverseDemo(int vertex){
		Vertex = vertex;
		adjacencyList = new LinkedList [vertex];
		for (int i=0; i<vertex; ++i)
			adjacencyList[i] = new LinkedList();
		}

	void addEdge(int start, int end) { 
		adjacencyList[start].add(end); 
	}
	void BreadthFirstSearch(int startPoint){
		boolean VertexVisited[] = new boolean [Vertex];
		LinkedList<Integer> bfsList = new LinkedList<>();
		VertexVisited [startPoint] = true;
		bfsList.add(startPoint);

		while (bfsList.size() != 0) {
			startPoint = bfsList.poll();
			System.out.print(startPoint + " ");
			Iterator<Integer> i = adjacencyList[startPoint]. listIterator();
			while (i.hasNext()){
				int j = i.next();
				if (!VertexVisited[j]) {
					VertexVisited[j] = true;
					bfsList.add(j);
				}
			}
		}
	}
	
	void DFS(int v, boolean visited[]) {
		visited [v] = true;
		System.out.print(v + " ");
		Iterator<Integer> i = adjacencyList[v]. listIterator();
		while (i.hasNext()) {
		int n = i.next();
		if (!visited [n])
		DFS(n, visited);
		}
	}
	void DepthFirstSearch(int v) {
		boolean visited[] = new boolean [Vertex];
		DFS(v, visited);
	}
}
public class TraverseGraph {

	public static void main(String[] args) {
		TraverseDemo myGraph = new TraverseDemo(9);

		myGraph.addEdge(0, 3);
		myGraph.addEdge(0, 4);
		myGraph.addEdge(0, 7);
		myGraph.addEdge(1, 2);
		myGraph.addEdge(1, 3);
		myGraph.addEdge(1, 5);
		myGraph.addEdge(1, 8);
		myGraph.addEdge(5, 2);
		myGraph.addEdge(6, 7);
		myGraph.addEdge(6, 8);
		myGraph.addEdge(6, 0);
		
		System.out.println("BFS Traversal from 6");
		myGraph.BreadthFirstSearch(6);
		System.out.println("\nDFS Traversal from 1");
		myGraph.DepthFirstSearch(1);
	}

}
