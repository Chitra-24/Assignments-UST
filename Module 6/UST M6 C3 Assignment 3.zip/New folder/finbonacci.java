package com.course_3;

public class finbonacci {

	static int fib(int x) {
		if(x==1)
			return 0;
		else if(x==2)
			return 1;
		else {
			return fib(x-1)+fib(x-2);
		}
	}
	 public static int LongestCommonSubsequence(char[] X,char[] Y,int m,int n){
	        int[][] L = new int[m + 1][n + 1];

	        for (int i = 0; i <= m; i++) {
	            for (int j = 0; j <= n; j++) {
	                if (i == 0 || j == 0)
	                    L[i][j] = 0;
	                else if (X[i - 1] == Y[j - 1])
	                    L[i][j] = L[i - 1][j - 1] + 1;
	                else
	                    L[i][j] = Math.max(L[i - 1][j], L[i][j - 1]);
	            }
	        }
	        return L[m][n];
	    }

	public static void main(String[] args) {
		int x=8;
		for(int i=1;i<x+1;i++) {
			System.out.print(fib(i)+"\t");
		}
		String X = "ACE";
        String Y = "ABCDE";

        char[] z = X.toCharArray();
        char[] y = Y.toCharArray();
        int m = z.length;
        int n = y.length;
        System.out.println("\nLength of Longest Common subsequence: "+LongestCommonSubsequence(z, y, m, n));

	}
}
