package com.unitTest.assignment;

import java.util.Arrays;

public class ArraySortExample {
	    public int[] sortArray(int[] array) {
	        Arrays.sort(array);
	        return array;
	    }

	    public boolean isArrayEqual(int[] array1, int[] array2) {
	        return Arrays.equals(array1, array2);
	    }

	    public int[] reverseArray(int[] array) {
	        int[] reversedArray = new int[array.length];
	        for (int i = 0; i < array.length; i++) {
	            reversedArray[i] = array[array.length - i - 1];
	        }
	        return reversedArray;
	    }

	    public int[] findDuplicates(int[] array) {
	        int[] duplicates = new int[array.length];
	        int duplicatesIndex = 0;
	        for (int i = 0; i < array.length; i++) {
	            for (int j = i + 1; j < array.length; j++) {
	                if (array[i] == array[j]) {
	                    duplicates[duplicatesIndex++] = array[i];
	                }
	            }
	        }
	        int[] trimmedDuplicates = new int[duplicatesIndex];
	        System.arraycopy(duplicates, 0, trimmedDuplicates, 0, duplicatesIndex);
	        return trimmedDuplicates;
	    }
}


