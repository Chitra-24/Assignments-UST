package com.unitTest.assignment;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Arrays;
public class ArraySortTest {
	    private ArraySortExample arrayOperations;
	        private int[] array;

	        @Before
	        public void setup() {
	        	System.out.println("Before: Executed before each test method.");
	            arrayOperations = new ArraySortExample();
	            array = new int[] {5, 2, 8, 3, 1, 4};
	        }

	        @After
	        public void tearDown() {
	        	System.out.println("After: Executed after each test method.");
	            array = null;
	        }

	        @BeforeClass
	        public static void setupClass() {
	            System.out.println("Setting up test class");
	        }

	        @AfterClass
	        public static void tearDownClass() {
	            System.out.println("Tearing down test class");
	        }

	        @Test
	        public void testSortArray() {
	            int[] sortedArray = arrayOperations.sortArray(array);
	            int[] expectedArray = new int[] {1, 2, 3, 4, 5, 8};
	            assertArrayEquals(expectedArray, sortedArray);
	        }

	        @Test
	        public void testIsArrayEqual() {
	            int[] array1 = new int[] {1, 2, 3};
	            int[] array2 = new int[] {1, 2, 3};
	            assertTrue(arrayOperations.isArrayEqual(array1, array2));
	        }

	        @Test
	        public void testReverseArray() {
	            int[] reversedArray = arrayOperations.reverseArray(array);
	            int[] expectedArray = new int[] {4, 1, 3, 8, 2, 5};
	            assertArrayEquals(expectedArray, reversedArray);
	        }

	        @Test
	        public void testFindDuplicates() {
	            int[] arrayWithDuplicates = new int[] {1, 2, 2, 3, 4, 4, 5};
	            int[] duplicates = arrayOperations.findDuplicates(arrayWithDuplicates);
	            int[] expectedDuplicates = new int[] {2, 4};
	            assertArrayEquals(expectedDuplicates, duplicates);
	        }
}
