package com.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import static org.mockito.Mockito.when;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

@RunWith(MockitoJUnitRunner.class)
public class ArraysTest {
	    @InjectMocks
	    private ArraysOperation arrayOperations;

	    @Mock
	    private Arrays arraysMock;

	    @Before
	    public void setup() {
	       //when(arraysMock.sort(any(int[].class))).thenReturn(new int[] {1, 2, 3});
	    }

	    @Test
	    public void testSortArray() {
	        int[] array = new int[] {3, 2, 1};
	        int[] sortedArray = arrayOperations.sortArray(array);
	        assertArrayEquals(new int[] {1, 2, 3}, sortedArray);
	        verify(arraysMock, times(1)).sort(any(int[].class));
	    }

	    @Test
	    public void testIsArrayEqual() {
	        int[] array1 = new int[] {1, 2, 3};
	        int[] array2 = new int[] {1, 2, 3};
	        assertTrue(arrayOperations.isArrayEqual(array1, array2));
	    }

	    @Test
	    public void testReverseArray() {
	        int[] array = new int[] {1, 2, 3};
	        int[] reversedArray = arrayOperations.reverseArray(array);
	        assertArrayEquals(new int[] {3, 2, 1}, reversedArray);
	    }

	    @Test
	    public void testFindDuplicates() {
	        int[] arrayWithDuplicates = new int[] {1, 2, 2, 3, 4, 4, 5};
	        int[] duplicates = arrayOperations.findDuplicates(arrayWithDuplicates);
	        assertArrayEquals(new int[] {2, 4}, duplicates);
	    }
}
