package com.M8.C1;

import jdk.jshell.*;

import java.util.List;
import java.util.Scanner;

public class MathEvaluator {

    public static void main(String[] args) {
        JShell jShell = JShell.create();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter a mathematical expression (type 'exit' to quit): ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            List<SnippetEvent> events = jShell.eval(input);

            for (SnippetEvent event : events) {
                if (event.status() == Snippet.Status.VALID) {
                    System.out.println("Result: " + event.value());
                } else {
                    System.out.println("Invalid expression. Please try again.");
                }
            }
        }
    }
}
