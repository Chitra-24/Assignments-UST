package com.M8.C1;

import jdk.jshell.JShell;
import jdk.jshell.SnippetEvent;
import jdk.jshell.Snippet.Status;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        JShell jshell = JShell.create();
        Scanner sc = new Scanner(System.in);
        List<String> history = new ArrayList<>();
        List<String> results = new ArrayList<>();
        String input;

        System.out.println("Welcome to the Enhanced Calculator!");
        System.out.println("Type 'exit' to quit, 'history' to see previous expressions.");

        while (true) {
            System.out.print(">> ");
            input = sc.nextLine().trim();
            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            if (input.equalsIgnoreCase("history")) {
                showHistory(history, results);
                continue;
            }

            // Evaluate expressions using JShell
            List<SnippetEvent> events = jshell.eval(input);
            StringBuilder result = new StringBuilder();
            boolean error = false;

            for (SnippetEvent event : events) {
                if (event.status() == Status.VALID) {
                    result.append(event.value()).append("\n");
                } else {
                    result.append("Error: ").append(event.exception().getMessage()).append("\n");
                    error = true;
                    break;
                }
            }

            String resultString = result.toString().trim();
            if (!error) {
                history.add(input);
                results.add(resultString);
            }
            System.out.println(resultString);
        }

        jshell.close();
        sc.close();
    }

    private static void showHistory(List<String> history, List<String> results) {
        if (history.isEmpty()) {
            System.out.println("No history available.");
        } else {
            for (int i = 0; i < history.size(); i++) {
                System.out.println((i + 1) + ": " + history.get(i) + " = " + results.get(i));
            }
        }
    }
}
