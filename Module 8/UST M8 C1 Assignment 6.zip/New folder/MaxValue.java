package com.M8.C1;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class MaxValue {
    public static void main(String[] args) {
        List<Double> doubles = Arrays.asList(1.5, 2.8, 3.2, 2.0, 5.1);
        Optional<Double> maxElement = doubles.stream()
                                             .max((a, b) -> Double.compare(a, b));
        if (maxElement.isPresent()) {
            System.out.println("The maximum element is: " + maxElement.get());
        } else {
            System.out.println("The list is empty.");
        }
    }
}
