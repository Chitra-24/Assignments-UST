package com.M8.C1;

import java.util.Arrays;
import java.util.List;

public class StringConCate {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("Java", "is", "fun", "with", "Streams");
        String concatenatedString = words.stream()
                                         .reduce("", (a, b) -> a + b);
        System.out.println("The concatenated string is: " + concatenatedString);
    }
}

