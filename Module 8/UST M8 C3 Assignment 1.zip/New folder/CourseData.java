package com.M8.C3;

import java.util.ArrayList;
import java.util.List;

 class Course {
    private Integer courseId;
    private String courseName;
    private Double courseFee;
    private Integer duration;

    public Course(Integer courseId, String courseName, Double courseFee, Integer duration) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.courseFee = courseFee;
        this.duration = duration;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Double getCourseFee() {
        return courseFee;
    }

    public void setCourseFee(Double courseFee) {
        this.courseFee = courseFee;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }
}

public class CourseData {
    private static final List<Course> courseList = new ArrayList<>();

    static {
        courseList.add(new Course(101, "BTech", 450000.00, 48));
        courseList.add(new Course(202, "MTech", 405000.00, 24));
        courseList.add(new Course(303, "BCA", 425000.00, 48));
        courseList.add(new Course(404, "MCA", 450000.00, 24));
    }

    private static CourseData instance = null;
    private CourseData() {}
    public static CourseData getInstance() {
        if (instance == null) {
            synchronized (CourseData.class) {
                if (instance == null) {
                    instance = new CourseData();
                }
            }
        }
        return instance;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }

    protected Object readResolve() {
        return getInstance();
    }

    public List<Course> getCourseList() {
        return courseList;
    }
}
