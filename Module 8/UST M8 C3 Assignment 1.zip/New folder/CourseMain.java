package com.M8.C3;

public class CourseMain {
    public static void main(String[] args) {

        CourseData courseData1 = CourseData.getInstance();
        CourseData courseData2 = CourseData.getInstance();
        System.out.println("Hash code of courseData1: " + courseData1.hashCode());
        System.out.println("Hash code of courseData2: " + courseData2.hashCode());

        System.out.println("Courses in the course list:");
        for (Course course : courseData1.getCourseList()) {
            System.out.println("Course ID: " + course.getCourseId() +
                               ", Name: " + course.getCourseName() +
                               ", Fee: " + course.getCourseFee() +
                               ", Duration: " + course.getDuration() + " months");
        }
    }
}
