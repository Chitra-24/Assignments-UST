package com.M8.Bill;

import java.util.List;

public class Bill {
    private Integer billNumber;
    private String customerName;
    private List<Order> orderList;
    private Double billAmount;
    private Double finalAmount;
    private PaymentStrategy paymentStrategy;

    public Bill(Integer billNumber, String customerName, List<Order> orderList, PaymentStrategy paymentStrategy) {
        this.billNumber = billNumber;
        this.customerName = customerName;
        this.orderList = orderList;
        this.paymentStrategy = paymentStrategy;
        this.billAmount = calculateBillAmount();
        this.finalAmount = paymentStrategy.calculateFinalAmount(billAmount);
    }

    private Double calculateBillAmount() {
        double amount = 0.0;
        for (Order order : orderList) {
            amount += order.getPrice() * order.getOrderedQuantity();
        }
        return amount;
    }

    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
        this.finalAmount = paymentStrategy.calculateFinalAmount(billAmount);
    }

    public Double getFinalAmount() {
        return finalAmount;
    }
}
