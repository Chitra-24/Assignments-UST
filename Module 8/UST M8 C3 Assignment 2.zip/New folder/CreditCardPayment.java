package com.M8.Bill;

public class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;
    private String expiryDate;

    public CreditCardPayment(String cardNumber, String expiryDate) {
        this.cardNumber = cardNumber;
        this.expiryDate = expiryDate;
    }

    @Override
    public double calculateFinalAmount(double billAmount) {
        return billAmount; // No extra charges for credit card payment
    }
}
