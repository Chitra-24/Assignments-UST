package com.M8.Bill;

public class EPayment implements PaymentStrategy {
    private String cashCardName;
    private String cardNumber;
    private String expiryDate;

    public EPayment(String cashCardName, String cardNumber, String expiryDate) {
        this.cashCardName = cashCardName;
        this.cardNumber = cardNumber;
        this.expiryDate = expiryDate;
    }

    @Override
    public double calculateFinalAmount(double billAmount) {
        return billAmount * 1.05; // 5% extra charge for e-payment
    }
}

