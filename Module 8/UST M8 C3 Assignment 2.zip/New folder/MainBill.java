package com.M8.Bill;

import java.util.Arrays;
import java.util.List;

public class MainBill {
    public static void main(String[] args) {
        Order order1 = new Order(1, "Item1", 100.0, 2.0);
        Order order2 = new Order(2, "Item2", 150.0, 3.0);

        List<Order> orders = Arrays.asList(order1, order2);

        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9012-3456", "12/24");
        PaymentStrategy netBankingPayment = new NetBankingPayment("BankName", "123456789", "IFSC1234");
        PaymentStrategy ePayment = new EPayment("PayPal", "9876-5432-1098-7654", "11/23");

        Bill bill1 = new Bill(1, "Customer A", orders, creditCardPayment);
        System.out.println("Final amount with Credit Card Payment: " + bill1.getFinalAmount());

        Bill bill2 = new Bill(2, "Customer B", orders, netBankingPayment);
        System.out.println("Final amount with Net Banking Payment: " + bill2.getFinalAmount());

        Bill bill3 = new Bill(3, "Customer C", orders, ePayment);
        System.out.println("Final amount with E-Payment: " + bill3.getFinalAmount());
    }
}
