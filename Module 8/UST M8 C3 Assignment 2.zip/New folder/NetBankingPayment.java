package com.M8.Bill;

public class NetBankingPayment implements PaymentStrategy {
    private String bankName;
    private String accountNumber;
    private String ifscCode;

    public NetBankingPayment(String bankName, String accountNumber, String ifscCode) {
        this.bankName = bankName;
        this.accountNumber = accountNumber;
        this.ifscCode = ifscCode;
    }

    @Override
    public double calculateFinalAmount(double billAmount) {
        return billAmount * 1.025; // 2.5% extra charge for net banking
    }
}

