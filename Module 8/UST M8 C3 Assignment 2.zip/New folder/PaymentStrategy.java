package com.M8.Bill;

public interface PaymentStrategy {
    double calculateFinalAmount(double billAmount);
}
