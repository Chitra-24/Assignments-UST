package com.M8.C3;
import java.util.Scanner;

interface Shape {
 public double perimeterCalculation();
 public double areaCalculation();
}

class Circle implements Shape {
 private double radius;

 public Circle(double radius) {
     this.radius = radius;
 }

 @Override
 public double perimeterCalculation() {
     return 2 * Math.PI * radius;
 }

 @Override
 public double areaCalculation() {
     return Math.PI * radius * radius;
 }
}

class Ellipse implements Shape {
 private double longRadius;
 private double shortRadius;

 public Ellipse(double longRadius, double shortRadius) {
     this.longRadius = longRadius;
     this.shortRadius = shortRadius;
 }

 @Override
 public double perimeterCalculation() {
     double h = (longRadius - shortRadius) / (longRadius + shortRadius);
     double p = Math.PI * (longRadius + shortRadius) * (1 + (3 * h * h) / (10 + Math.sqrt(4 - 3 * h * h)));
     return p;
 }

 @Override
 public double areaCalculation() {
     return Math.PI * longRadius * shortRadius;
 }
}

class ShapeFactory {
 public static Shape getShapeFactory(double x) {
     return new Circle(x);
 }

 public static Shape getShapeFactory(double x, double y) {
     return new Ellipse(x, y);
 }
}

public class FactoryPattern {
 public static void main(String[] args) {
	 Scanner sc=new Scanner(System.in);
     while (true) {
         System.out.println("1. Circle");
         System.out.println("2. Ellipse");
         System.out.println("3. Exit");
         System.out.print("Enter choice (1-3): ");
         int choice = sc.nextInt();

         if (choice == 3) {
             break;
         }

         double radius1, radius2;
         Shape shape;

         if (choice == 1) {
             System.out.print("Enter radius of circle: ");
             radius1 = Double.parseDouble(sc.next());
             shape = ShapeFactory.getShapeFactory(radius1);
         } else {
             System.out.print("Enter long radius of ellipse: ");
             radius1 = Double.parseDouble(sc.next());
             System.out.print("Enter short radius of ellipse: ");
             radius2 = Double.parseDouble(sc.next());
             shape = ShapeFactory.getShapeFactory(radius1, radius2);
         }

         System.out.println("Perimeter: " + shape.perimeterCalculation());
         System.out.println("Area: " + shape.areaCalculation());
         System.out.println();
     }
 }
}
