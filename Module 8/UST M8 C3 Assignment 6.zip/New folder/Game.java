package com.M8.C3;

 interface CharacterFactory {
    Character createCharacter();
}
 interface Character {
    void attack();
    void defend();
}

 class Warrior implements Character {
    @Override
    public void attack() {
        System.out.println("The warrior attacks with a sword!");
    }

    @Override
    public void defend() {
        System.out.println("The warrior raises a shield to defend!");
    }
}

 class Mage implements Character {
    @Override
    public void attack() {
        System.out.println("The mage casts a fireball!");
    }

    @Override
    public void defend() {
        System.out.println("The mage casts a protective shield!");
    }
}

 class Archer implements Character {
    @Override
    public void attack() {
        System.out.println("The archer fires an arrow!");
    }

    @Override
    public void defend() {
        System.out.println("The archer readies a shield!");
    }
}

 class WarriorFactory implements CharacterFactory {
    @Override
    public Character createCharacter() {
        return new Warrior();
    }
}

 class MageFactory implements CharacterFactory {
    @Override
    public Character createCharacter() {
        return new Mage();
    }
}

 class ArcherFactory implements CharacterFactory {
    @Override
    public Character createCharacter() {
        return new Archer();
    }
}
public class Game {
    public static void main(String[] args) {
        CharacterFactory warriorFactory = new WarriorFactory();
        Character warrior = warriorFactory.createCharacter();
        warrior.attack();
        warrior.defend();

        CharacterFactory mageFactory = new MageFactory();
        Character mage = mageFactory.createCharacter();
        mage.attack();
        mage.defend();

        CharacterFactory archerFactory = new ArcherFactory();
        Character archer = archerFactory.createCharacter();
        archer.attack();
        archer.defend();
    }
}