package com.M8.C3;

 interface GUIComponent {
    void draw();
}
 interface GUIComponentFactory {
    Button createButton(String label);
    TextField createTextField(int size);
}

 class Button implements GUIComponent {
    private String label;

    public Button(String label) {
        this.label = label;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a button with label: " + label);
    }
}

 class TextField implements GUIComponent {
    private int size;

    public TextField(int size) {
        this.size = size;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a text field with size: " + size);
    }
}
 class LightThemeFactory implements GUIComponentFactory {
    @Override
    public Button createButton(String label) {
        return new Button(label);
    }

    @Override
    public TextField createTextField(int size) {
        return new TextField(size);
    }
}

 class DarkThemeFactory implements GUIComponentFactory {
    @Override
    public Button createButton(String label) {
        return new Button("Dark " + label);
    }

    @Override
    public TextField createTextField(int size) {
        return new TextField(size * 2);
    }
}
public class Application {
    public static void main(String[] args) {
        GUIComponentFactory lightFactory = new LightThemeFactory();
        GUIComponentFactory darkFactory = new DarkThemeFactory();

        GUIComponent button1 = lightFactory.createButton("OK");
        GUIComponent button2 = darkFactory.createButton("Cancel");
        GUIComponent textField1 = lightFactory.createTextField(10);
        GUIComponent textField2 = darkFactory.createTextField(20);

        button1.draw();
        button2.draw();
        textField1.draw();
        textField2.draw();
    }
}