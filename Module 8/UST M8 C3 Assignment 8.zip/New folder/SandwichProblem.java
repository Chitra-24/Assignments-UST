package com.M8.C3;

import java.util.ArrayList;
import java.util.List;

interface Sandwich {
    void display();
}
 class SandwichImpl implements Sandwich {
    private String bread;
    private List<String> vegetables;
    private List<String> meats;
    private List<String> sauces;

    private SandwichImpl() {
        this.vegetables = new ArrayList<>();
        this.meats = new ArrayList<>();
        this.sauces = new ArrayList<>();
    }

    public static SandwichBuilder builder() {
        return new SandwichBuilder();
    }

    @Override
    public void display() {
        System.out.println("Bread: " + bread);
        System.out.println("Vegetables: " + vegetables);
        System.out.println("Meats: " + meats);
        System.out.println("Sauces: " + sauces);
    }

    public static class SandwichBuilder {
        private SandwichImpl sandwich;

        private SandwichBuilder() {
            this.sandwich = new SandwichImpl();
        }

        public SandwichBuilder setBread(String bread) {
            sandwich.bread = bread;
            return this;
        }

        public SandwichBuilder addVegetables(String... vegetables) {
            for (String vegetable : vegetables) {
                sandwich.vegetables.add(vegetable);
            }
            return this;
        }

        public SandwichBuilder addMeats(String... meats) {
            for (String meat : meats) {
                sandwich.meats.add(meat);
            }
            return this;
        }

        public SandwichBuilder addSauces(String... sauces) {
            for (String sauce : sauces) {
                sandwich.sauces.add(sauce);
            }
            return this;
        }

        public Sandwich build() {
            return sandwich;
        }
    }
}

public class SandwichProblem {
    public static void main(String[] args) {
        Sandwich sandwich = SandwichImpl.builder()
            .setBread("Italian bread")
            .addVegetables("lettuce", "tomato", "onion")
            .addMeats("ham", "turkey", "salami")
            .addSauces("mayo", "mustard", "italian dressing")
            .build();

        sandwich.display();
    }
}

