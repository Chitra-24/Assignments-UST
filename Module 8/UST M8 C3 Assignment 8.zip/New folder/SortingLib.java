package com.M8.C3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

interface SortingStrategy<T extends Comparable<T>> {
    void sort(List<T> list);
}
 class BubbleSort<T extends Comparable<T>> implements SortingStrategy<T> {
    @Override
    public void sort(List<T> list) {
        int n = list.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (list.get(j).compareTo(list.get(j + 1)) > 0) {
                    Collections.swap(list, j, j + 1);
                }
            }
        }
    }
}

 class MergeSort<T extends Comparable<T>> implements SortingStrategy<T> {
    @Override
    public void sort(List<T> list) {
        if (list.size() <= 1) {
            return;
        }
        int mid = list.size() / 2;
        List<T> left = new ArrayList<>(list.subList(0, mid));
        List<T> right = new ArrayList<>(list.subList(mid, list.size()));
        sort(left);
        sort(right);
        merge(list, left, right);
    }

    private void merge(List<T> list, List<T> left, List<T> right) {
        int i = 0, j = 0, k = 0;
        while (i < left.size() && j < right.size()) {
            if (left.get(i).compareTo(right.get(j)) <= 0) {
                list.set(k, left.get(i));
                i++;
            } else {
                list.set(k, right.get(j));
                j++;
            }
            k++;
        }
        while (i < left.size()) {
            list.set(k, left.get(i));
            i++;
            k++;
        }
        while (j < right.size()) {
            list.set(k, right.get(j));
            j++;
            k++;
        }
    }
}

 class QuickSort<T extends Comparable<T>> implements SortingStrategy<T> {
    @Override
    public void sort(List<T> list) {
        quickSort(list, 0, list.size() - 1);
    }

    private void quickSort(List<T> list, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(list, low, high);
            quickSort(list, low, pivotIndex - 1);
            quickSort(list, pivotIndex + 1, high);
        }
    }

    private int partition(List<T> list, int low, int high) {
        T pivot = list.get(high);
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (list.get(j).compareTo(pivot) < 0) {
                i++;
                Collections.swap(list, i, j);
            }
        }
        Collections.swap(list, i + 1, high);
        return i + 1;
    }
}
public class SortingLib {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(5, 3, 8, 4, 2);

        SortingStrategy<Integer> bubbleSort = new BubbleSort<>();
        SortingStrategy<Integer> mergeSort = new MergeSort<>();
        SortingStrategy<Integer> quickSort = new QuickSort<>();

        System.out.println("Original list: " + list);
        bubbleSort.sort(list);
        System.out.println("Bubble sorted list: " + list);

        list = Arrays.asList(5, 3, 8, 4, 2);
        System.out.println("Original list: " + list);
        mergeSort.sort(list);
        System.out.println("Merge sorted list: " + list);

        list = Arrays.asList(5, 3, 8, 4, 2);
        System.out.println("Original list: " + list);
        quickSort.sort(list);
        System.out.println("Quick sorted list: " + list);
    }
 }