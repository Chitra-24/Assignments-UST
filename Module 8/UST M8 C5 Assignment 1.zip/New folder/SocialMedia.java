package com.M8.C3;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Flow;
import java.util.concurrent.SubmissionPublisher;
import java.util.concurrent.atomic.AtomicInteger;

class TrendingHashtagsProcessor implements Flow.Subscriber<String> {
    private final Map<String, AtomicInteger> hashtagCounts = new ConcurrentHashMap<>();
    private final CountDownLatch latch;
    private Flow.Subscription subscription;

    public TrendingHashtagsProcessor(CountDownLatch latch) {
        this.latch = latch;
    }

    @Override
    public void onSubscribe(Flow.Subscription subscription) {
        this.subscription = subscription;
        subscription.request(Long.MAX_VALUE);
    }

    @Override
    public void onNext(String hashtag) {
        hashtagCounts.compute(hashtag, (k, v) -> {
            if (v == null) {
                v = new AtomicInteger(1);
            } else {
                v.incrementAndGet();
            }
            return v;
        });
    }

    @Override
    public void onError(Throwable throwable) {
        throwable.printStackTrace();
        latch.countDown(); // Ensure latch is decremented on error
    }

    @Override
    public void onComplete() {
        System.out.println("Top Trending Hashtags: " + getTopTrendingHashtags());
        latch.countDown(); // Decrement latch when processing is complete
    }

    public String getTopTrendingHashtags() {
        return hashtagCounts.entrySet().stream()
                .sorted((e1, e2) -> e2.getValue().get() - e1.getValue().get())
                .limit(3)
                .map(Map.Entry::getKey)
                .reduce((a, b) -> a + ", " + b)
                .orElse("");
    }
}

class TrendingHashtagsPublisher implements Flow.Publisher<String> {
    private final SubmissionPublisher<String> publisher = new SubmissionPublisher<>();

    @Override
    public void subscribe(Flow.Subscriber<? super String> subscriber) {
        publisher.subscribe(subscriber);
    }

    public void publishHashtag(String hashtag) {
        publisher.submit(hashtag);
    }

    public void complete() {
        publisher.close();
    }
}

public class SocialMedia {
    public static void main(String[] args) throws InterruptedException {

        CountDownLatch latch = new CountDownLatch(1);
        TrendingHashtagsPublisher hashtagsPublisher = new TrendingHashtagsPublisher();

        TrendingHashtagsProcessor hashtagsProcessor = new TrendingHashtagsProcessor(latch);

        hashtagsPublisher.subscribe(hashtagsProcessor);

        hashtagsPublisher.publishHashtag("#Java");
        hashtagsPublisher.publishHashtag("#ReactiveProgramming");
        hashtagsPublisher.publishHashtag("#Java9");
        hashtagsPublisher.publishHashtag("#Concurrency");
        
        hashtagsPublisher.complete();

        latch.await();
    }
}
