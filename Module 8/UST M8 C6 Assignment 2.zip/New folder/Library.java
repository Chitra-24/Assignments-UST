package com.M8;
import java.util.ArrayList;
import java.util.List;

public class Library {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<Book>();
    }

    public void addBook(String title, String author, int year) {
        Book book = new Book(title, author, year);
        books.add(book);
    }

    public void removeBook(String title) {
        books.removeIf(book -> book.getTitle().equals(title));
    }

    public Book findBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equals(title)) {
                return book;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Book book : books) {
            sb.append(book).append("\n");
        }
        return sb.toString();
    }

    // Nested class Book
    private class Book {
        private String title;
        private String author;
        private int year;

        public Book(String title, String author, int year) {
            this.title = title;
            this.author = author;
            this.year = year;
        }

        public String getTitle() {
            return title;
        }

        @Override
        public String toString() {
            return String.format("%s by %s (%d)", title, author, year);
        }
    }

    // Main method to demonstrate usage
    public static void main(String[] args) {
        Library library = new Library();
        library.addBook("The Great Gatsby", "F. Scott Fitzgerald", 1925);
        library.addBook("1984", "George Orwell", 1949);

        System.out.println("Library contents:");
        System.out.println(library);

        System.out.println("Finding '1984':");
        Book book = library.findBookByTitle("1984");
        System.out.println(book != null ? book : "Book not found");

        library.removeBook("1984");
        System.out.println("Library contents after removing '1984':");
        System.out.println(library);
    }
}
