package com.example.helloWorld;

import com.example.model.Employees;
import com.example.model.SimpleInterestCalculator;
import com.example.model.Addresses;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task1Application {
	public static void main(String[] args) {
		SpringApplication.run(Task1Application.class, args);
		        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		        Employees employee = (Employees) context.getBean("employee");
		        System.out.println("Employee Name: " + employee.getName());
		        System.out.println("Employee ID: " + employee.getId());

		        employee.getAddresses().forEach(address -> {
		            System.out.println("Street: " + address.getStreet());
		            System.out.println("City: " + address.getCity());
		            System.out.println("Zipcode: " + address.getZipCode());
		        });
		        
		        System.out.println();
		        SimpleInterestCalculator sic=(SimpleInterestCalculator) context.getBean("interestCalculatorBean");
		        System.out.println("Simple interest:\n");
		        System.out.println(sic.calculateSimpleInterest());
		    }
}
