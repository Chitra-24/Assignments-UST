package com.example.model;

import jakarta.persistence.Entity;

@Entity
public class Addresses {
    private String street;
    private String city;
    private String zipCode;

    public Addresses() {
    	
    }
    // Getter and Setter for 'street' property
    public String getStreet() {
        return street;
    }
    public void setStreet(String street) {
        this.street = street;
    }

    // Getter and Setter for 'city' property
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }

    // Getter and Setter for 'zipCode' property
    public String getZipCode() {
        return zipCode;
    }
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}


