package com.example.model;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
//import javax.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Employee")
public class Employees {
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	public String id;
    private String name;
    private List<Addresses> address;

    public Employees() {
    	
    }
    // Getter and Setter for 'name' property
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for 'addresses' property
    public List<Addresses> getAddresses() {
        return address;
    }
    public void setAddresses(List<Addresses> address) {
        this.address = address;
    }
    public void setId(String id) {
    	this.id=id;
    }
	public String getId() {
		return id;
	}
}

