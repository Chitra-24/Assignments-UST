package com.example.model;

public class SimpleInterestCalculator {
    private double principal;
    private double rate;
    private double time;

    // Getter and Setter for 'principal' property
    public double getPrincipal() {
        return principal;
    }
    public void setPrincipal(double principal) {
        this.principal = principal;
    }

    // Getter and Setter for 'rate' property
    public double getRate() {
        return rate;
    }
    public void setRate(double rate) {
        this.rate = rate;
    }

    // Getter and Setter for 'time' property
    public double getTime() {
        return time;
    }
    public void setTime(double time) {
        this.time = time;
    }

    // Method to calculate simple interest
    public double calculateSimpleInterest() {
        return (principal * rate * time) / 100;
    }
}
