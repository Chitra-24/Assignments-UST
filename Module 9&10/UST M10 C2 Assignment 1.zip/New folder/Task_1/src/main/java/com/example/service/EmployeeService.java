package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.model.Employees;

public interface EmployeeService {
    Employees getEmployeeDetails();
}

 class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private Employees employee; // Inject the Employee bean

    @Override
    public Employees getEmployeeDetails() {
        return employee;
    }
}

