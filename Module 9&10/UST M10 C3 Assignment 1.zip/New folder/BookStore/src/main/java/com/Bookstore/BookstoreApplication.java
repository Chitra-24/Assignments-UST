package com.Bookstore;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BookstoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookstoreApplication.class, args);
    }

    @Bean
    CommandLineRunner run(BookRepository repository) {
        return args -> {
            // Create a new book
            Book book = new Book("The Great Gatsby", "F. Scott Fitzgerald");
            Book savedBook = repository.save(book);

            System.out.println("Book Added:\n" +"ID: "+ savedBook.getId() + "\n" +"Title: "+ savedBook.getTitle() + "\n" + "Authour: "+ savedBook.getAuthor()+"\n");

            // Retrieve the added book
            Book retrievedBook = repository.findById(savedBook.getId()).orElse(null);
            System.out.println("Retrieved Book:\n" +"ID: "+ retrievedBook.getId() + "\n" + "Title: "+retrievedBook.getTitle() + "\n" + "Author: "+retrievedBook.getAuthor()+"\n");

            // Update the book's information
            retrievedBook.setAuthor("F. Scott Fitzgerald (Updated)");
            Book updatedBook = repository.save(retrievedBook);
            System.out.println("Book Updated:\n" +"ID: "+ updatedBook.getId() + "\n" + "Title: "+updatedBook.getTitle() + "\n" + "Author: "+updatedBook.getAuthor()+"\n");

            // Delete the book
            repository.delete(updatedBook);
            System.out.println("Book Deleted Successfully\n");

            // Try to retrieve the deleted book
            Book deletedBook = repository.findById(updatedBook.getId()).orElse(null);
            if (deletedBook == null) {
            	System.out.println("Attempting to Retrive Deleted Book:");
                System.out.println("Book Not Found");
            }
        };
    }
}
